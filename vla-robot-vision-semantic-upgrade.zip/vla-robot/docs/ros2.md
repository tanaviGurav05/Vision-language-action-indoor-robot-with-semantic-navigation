# Moving to ROS 2
Implement `ROS2Robot` (backend/robotics/interfaces.py): `get_state` from `/odom` + `/battery_state`, `move_to`/goal via
Nav2 `NavigateToPose`, `halt`/`emergency_stop` via `/cmd_vel` zero + Nav2 cancel. Implement `ROS2Navigation.plan` with
Nav2's planner service. Replace the construction of `SimulationRobot`/`SimulationNavigation` in `Engine.__init__` with a
factory driven by `ROBOT_MODE`. API, tools and dashboard stay unchanged. Note: the current navigate loop is tick-based;
for Nav2 replace it with goal-feedback callbacks while keeping the same result dictionary.
