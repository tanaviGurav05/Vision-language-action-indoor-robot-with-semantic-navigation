# Real Camera, Open-Vocabulary Detection and Semantic Task Handoff

This feature adds optional real-image inference alongside the existing simulator.

## Install optional dependencies

From the project root, with the project's virtual environment active:

```powershell
python -m pip install -r requirements-vision.txt
```

The first inference may download model weights. CPU inference works but may be slow. An internet connection is normally needed for the first model download.

## Run the app

Terminal 1:

```powershell
python -m uvicorn backend.main:app --reload
```

Terminal 2:

```powershell
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`, then Camera / Vision.

1. Choose **Start webcam** and allow browser camera access.
2. Choose **YOLO-World — open vocabulary** to try custom text prompts, including `pen`, `pencil`, `paper sheet`, `book`, `tea cup`, and `computer mouse`.
3. Press **Detect frame**. Inference runs on the current frame, not continuously; this avoids saturating a laptop CPU with repeated inference.
4. Alternatively upload a JPG, PNG or WEBP image.
5. Review bounding boxes and confidence. Enter an object target and choose **Understand scene** to receive a grounded summary, matching detections and recommended next steps.
6. Use **Task hand-off** to submit a reviewed natural-language command to the existing robot workflow.

## Detector limitations

- Standard `yolov8n.pt` is trained on COCO classes. It commonly recognizes person, bottle, cup, laptop, mouse and chair, but pen, pencil, paper and book are not reliable distinct COCO labels.
- YOLO-World accepts custom text classes and may recognize those objects, but is not guaranteed to detect every item. Small objects, glare, blur, occlusion, prompt wording and similar-looking objects affect performance.
- A detector label is evidence, not proof. Check confidence and the image. A confidence score is not a calibrated probability of correctness.
- A webcam bounding box does not provide a real-world 3D position. The task hand-off submits a command to the existing planner, which remains the simulation workflow unless separately connected to a calibrated robot localization system. This feature does not autonomously drive a physical robot toward an object.

## API endpoints

- `POST /api/vision/detect`: existing simulator detection.
- `GET /api/vision/object-classes`: model guidance and suggested prompts.
- `POST /api/vision/detect-image`: multipart image inference; fields are `file`, `model_type` (`yolo` or `world`), `classes` (comma-separated prompts), and `confidence_threshold`.
- `POST /api/vision/interpret`: deterministic interpretation of supplied detection evidence and optional target.

Image uploads are limited to JPG/PNG/WEBP and 8 MB. Optional model dependencies are loaded lazily, so the simulation does not require them.
