# Architecture
```
Frontend (React) --REST/WS--> FastAPI routes --> Engine
Engine components: CommandParser, TaskPlanner, ToolManager, PermissionManager, SafetyManager,
  SemanticMap, Localizer, SimulationNavigation (A*/Dijkstra), Simulator (dynamic obstacles),
  MockDetector, TaskVerifier, AuditLogger, MetricsEngine, Persistence (SQLAlchemy)
Robot layer: RobotInterface / NavigationInterface -> Simulation* (default) or ROS2* (stubs)
```
Execution flow of one task: parse -> (deny / reject / ask confirmation) -> plan steps -> for each step call a tool
via ToolManager (permission + schema check, timing, audit) -> navigation loop (tick, sense, safety stop, replan, move)
-> detection -> verification (checks + confidence) -> report -> metrics + DB.
Concurrency: one navigation task at a time (run lock); stop/pause/resume/e-stop bypass the lock. The engine runs in
worker threads and publishes events to listeners; the WebSocket manager forwards them to the browser thread-safely.
Failure isolation: tool errors, DB errors and listener errors are caught so one failure never crashes the system.
