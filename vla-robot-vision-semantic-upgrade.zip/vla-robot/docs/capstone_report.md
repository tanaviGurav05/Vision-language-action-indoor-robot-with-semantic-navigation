# Capstone Report: Vision-Language-Action Indoor Robot with Semantic Navigation and Tool Use

## 1. Problem Statement
Indoor robots usually follow pre-defined waypoints and cannot interpret natural-language instructions or react to a
changing environment. The project builds a system that understands a command, grounds it in a semantic map and
camera observations, acts through controlled tools, verifies the outcome and reports with a confidence.

## 2. Existing System
Waypoint-following robots: fixed routes, no language interface, no semantic grounding, limited explanation of
failures, and often no auditable safety layer around higher-level (AI) decisions.

## 3. Proposed System
A modular pipeline (parser, planner, tools, navigation, vision, verification, safety, audit, metrics) with a
simulation backend that is swappable for ROS 2 through abstract robot/navigation interfaces, plus a real-time dashboard.

## 4. Objectives
Understand commands; detect objects/landmarks; keep a semantic map; localize; plan and replan paths; avoid
obstacles; call tools under permissions; verify tasks; be confidence-aware; keep an audit trail; measure performance.

## 5. System Architecture
See `docs/architecture.md`. Layers: UI -> API -> Engine -> (tools, safety, perception, navigation) -> robot interface.

## 6. Methodology
Iterative development in 20 phases; each module has unit tests; evaluation by scripted scenarios run on isolated simulator instances.

## 7. AI Pipeline
Rule-based NLU: regex + alias tables + fuzzy matching (difflib) produce intent (NAVIGATE, SEARCH_OBJECT,
NAVIGATE_AND_SEARCH, STOP/PAUSE/RESUME/STATUS, UNAUTHORIZED, UNKNOWN), destination, object and a confidence.
Fuzzy matches get a lowered confidence (1 - 4*(1-similarity)); below the 60% threshold the system asks for confirmation.
A rule-based planner decomposes intents into steps (navigate, scan, detect_object, verify, report). The design allows an
LLM planner to be placed in front with this planner as the deterministic fallback.

## 8. Vision Pipeline
`MockDetector` simulates a camera from world state: objects in the same room (or within 2 m) are detected with
Gaussian confidence (mean 0.93), a 3% miss rate and a 2% false-positive rate; a degraded mode (mean 0.45) models poor
conditions. A semantic reasoner produces a scene caption and infers the room from object co-occurrence. `YoloDetector`
wraps Ultralytics for real images. Detection counts are compared with ground truth to compute vision accuracy.

## 9. Navigation Pipeline
Grid map (30 x 18 m, 1 m cells), 8-connected A* (octile heuristic) or Dijkstra, no diagonal corner-cutting. Each tick the
simulator moves dynamic obstacles; if an obstacle lies within the stop distance (2 m) on the path, the robot halts,
a safety event is logged, obstacles are inflated by 1 cell, the path is replanned and navigation continues. If no path
exists the robot waits up to 8 ticks, then fails safely.

## 10. Tool Use
Tools: navigate_to, detect_objects, search_object, get_robot_status, get_map, stop_robot, pause_task, resume_task,
emergency_stop, reset_emergency_stop. Each has a JSON schema, a permission level, execution time and status.
ToolManager validates role, confirmation and arguments, and catches all handler errors.

## 11. Safety
Emergency stop for every role; obstacle stop distance; blocked-area check; text screening denies attempts to weaken
safety ("disable/bypass ... safety"); high-risk actions need admin + confirmation; safety events are logged and counted.
The AI layers have no tool that can disable safety, so it cannot be bypassed by a command.

## 12. Database Design
SQLite via SQLAlchemy: users, robots, tasks, task_steps, landmarks, objects, navigation_runs, tool_calls, audit_logs,
safety_events, metrics. No SQLite-specific types, so a PostgreSQL URL works unchanged. Persistence is write-behind
with failures swallowed and logged, so a DB problem never stops the robot.

## 13. API Design
REST for commands/queries, WebSocket for live state/audit/task events; Pydantic validation; consistent error JSON. See `docs/api.md`.

## 14. Testing
35 pytest tests: parsing, planning, A*/Dijkstra, obstacle replanning, detector mock, tool permissions, safety, verification and API.

## 15. Evaluation
Seven scenarios, each on a fresh simulator, repeated for 20 random seeds (seed changes sensor noise, not geometry).
A scenario "passes" when the system behaves as expected, including correct refusals/failures.

## 16. Results
| Scenario | Pass rate | Avg sim time | Avg replans | Collisions (total) | Avg confidence |
|---|---|---|---|---|---|
| Simple navigation | 100% | 17.0 s | 0 | 0 | 100.0% |
| Navigation with obstacle | 100% | 21.0 s | 1 | 0 | 100.0% |
| Object search | 100% | 9.0 s | 0 | 0 | 96.7% |
| Multi-step task | 100% | 6.0 s | 0 | 0 | 97.6% |
| Low-confidence visual detection | 100% | 6.0 s | 0 | 0 | 45.2% |
| Unauthorized tool request | 100% | 0 s | 0 | 0 | 100.0% |
| Dynamic obstacle | 100% | 31.0 s | 2 | 0 | 98.3% |

Observations: all 140 runs behaved as expected; zero collisions; the obstacle and dynamic-person scenarios needed 1-2
replans. Low-confidence vision is correctly reported as a failure instead of a false "found". Path geometry is
deterministic, so time/replans do not vary across seeds; only confidence does.

## 17. Limitations
Simulated perception (no pixels), perfect odometry plus small noise, 2D grid world, rule-based NLU with limited
vocabulary, single robot, client-declared roles (no real authentication), in-memory task state during a run, the
frontend and API layer were not exercised in the authoring environment's automated tests (they require installing
dependencies), and no ROS 2 hardware validation.

## 18. Future Scope
ROS 2 + Nav2 + Gazebo; real RGB-D camera with YOLO/CLIP open-vocabulary detection; LLM planner with fallback;
SLAM-built semantic maps; multi-robot coordination; OAuth/JWT; PostgreSQL and OpenTelemetry export; user studies.
