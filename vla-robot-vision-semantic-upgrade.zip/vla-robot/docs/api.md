# API
Base URL `http://localhost:8000`. Interactive docs: `/docs`. Roles: `viewer | operator | admin` (client-declared in this prototype).

| Method | Path | Purpose |
|---|---|---|
| POST | /api/commands | `{command, role, execute, wait, options{inject_obstacle,dynamic_obstacle,degrade_vision}}` -> task |
| POST/GET | /api/tasks, /api/tasks/{id} | create / list / read tasks |
| POST | /api/tasks/{id}/confirm | confirm a low-confidence task |
| POST | /api/navigation/start `{destination}` | navigate (creates a task) |
| POST | /api/navigation/stop | stop robot |
| GET | /api/navigation/status | state, planned/actual path |
| GET | /api/robot/status | pose, battery, localization |
| POST | /api/vision/detect | run detector at current pose |
| GET | /api/map, /api/landmarks | semantic map |
| GET | /api/tools, /api/tools/history | tool specs and call history |
| POST | /api/tools/execute | `{tool, arguments, role, confirm}` |
| POST | /api/safety/emergency-stop | always allowed |
| POST | /api/safety/reset?role=admin&confirm=true | clear e-stop |
| GET | /api/safety/events | safety events |
| GET | /api/audit/logs?type=&search=&severity=&task_id=&limit= | audit trail |
| GET | /api/audit/db-counts | rows per DB table |
| GET | /api/metrics | computed metrics |
| GET/POST | /api/experiments/scenarios, /api/experiments/run | evaluation |
| GET | /api/system/status | mode, AI components, busy state |
| POST | /api/system/reset | reset simulation |
| WS | /ws | pushes `state`, `audit`, `task` messages |

Sample: `POST /api/commands {"command":"Go to the reception and find a chair"}` ->
`{"task_id":"TASK-001","intent":"navigate_and_search","destination":"Reception","target_object":"chair","confidence":0.95,"status":"planned", ...}`
(status moves to `running` then `completed`/`failed`; `wait:true` blocks until finished.)
Errors: `{"error":"CODE","message":"friendly text"}` (400) / validation 422.
