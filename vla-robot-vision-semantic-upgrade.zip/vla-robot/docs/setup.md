# Setup (Windows + VS Code)
1. Install Python 3.11+ and Node.js 18+.
2. `python -m venv venv` then `venv\Scripts\activate` then `pip install -r requirements.txt`.
3. `copy .env.example .env` (no secrets are needed for simulation mode).
4. Backend: `uvicorn backend.main:app --reload` (port 8000).
5. Frontend: `cd frontend`, `npm install`, `npm run dev` (port 5173; proxies /api and /ws to 8000).
6. Tests: `pytest` from the project root.
Troubleshooting: if PowerShell blocks activation run `Set-ExecutionPolicy -Scope Process RemoteSigned`.
If the dashboard shows "offline", the backend is not running or port 8000 is busy.
Optional real vision: `pip install ultralytics torch` (used by `YoloDetector.detect_image`).
