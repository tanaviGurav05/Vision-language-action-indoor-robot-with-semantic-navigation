def test_emergency_stop_blocks_navigation(engine):
    engine.tools.execute("emergency_stop", {}, "viewer")  # anyone may stop the robot
    t = engine.submit_command("Go to the kitchen", wait=True)
    assert t["status"] == "rejected" and engine.safety.estop


def test_reset_needs_admin_and_confirmation(engine):
    engine.emergency_stop()
    assert engine.tools.execute("reset_emergency_stop", {}, "operator")["status"] == "denied"
    assert engine.tools.execute("reset_emergency_stop", {}, "admin")["status"] == "needs_confirmation"
    assert engine.tools.execute("reset_emergency_stop", {}, "admin", confirmed=True)["success"]
    assert not engine.safety.estop


def test_obstacle_distance_rule(engine):
    assert engine.safety.should_stop_for_obstacle(1.0) and not engine.safety.should_stop_for_obstacle(5.0)


def test_blocked_destination_rejected(engine):
    ok, _ = engine.safety.validate_destination(engine.map, (10, 5))
    assert not ok
