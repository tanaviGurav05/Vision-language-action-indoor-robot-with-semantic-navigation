from backend.ai.real_vision import canonical_object, interpret_detections


def test_canonical_object_aliases():
    assert canonical_object('water bottle') == 'water bottle'
    assert canonical_object('computer mouse') == 'mouse'
    assert canonical_object('paper sheet') == 'paper'
    assert canonical_object('tea cup') == 'tea cup'


def test_semantic_interpretation_matches_target_with_evidence():
    detections = [
        {"label": "bottle", "canonical_label": "water bottle", "confidence": 0.91,
         "bbox": {"x": 12, "y": 15, "w": 30, "h": 55}},
        {"label": "person", "canonical_label": "person", "confidence": 0.87,
         "bbox": {"x": 80, "y": 5, "w": 60, "h": 100}},
    ]
    result = interpret_detections(detections, "water bottle")
    assert result["verified"] is True
    assert len(result["matches"]) == 1
    assert "water bottle" in result["summary"]
    assert result["recommended_next_steps"]


def test_semantic_interpretation_does_not_confirm_low_confidence():
    result = interpret_detections([{"label": "pen", "confidence": 0.42, "bbox": {}}], "pen")
    assert result["verified"] is False
    assert "could not confirm" in result["summary"]
