def test_verified_search_success(engine):
    t = engine.submit_command("Go to the kitchen and find a water bottle", wait=True)
    r = t["result"]
    assert t["status"] == "completed" and r["status"] == "SUCCESS" and r["confidence"] > 0.6
    assert all(c["passed"] for c in r["checks"])


def test_low_confidence_vision_fails_verification(engine):
    t = engine.submit_command("Go to the kitchen and find a water bottle", wait=True, options={"degrade_vision": True})
    assert t["status"] == "failed" and "reliably detected" in t["result"]["reason"]


def test_missing_object_fails(engine):
    t = engine.submit_command("Go to the kitchen and find a laptop", wait=True)
    assert t["status"] == "failed"
