def test_viewer_cannot_navigate(engine):
    r = engine.tools.execute("navigate_to", {"location": "Kitchen"}, role="viewer")
    assert r["status"] == "denied" and engine.safety.events


def test_unknown_tool(engine):
    r = engine.tools.execute("self_destruct", {}, "admin")
    assert r["status"] == "failed" and "not available" in r["error"]


def test_missing_argument(engine):
    r = engine.tools.execute("navigate_to", {}, "operator")
    assert not r["success"] and "Missing" in r["error"]


def test_get_robot_status_and_schema(engine):
    r = engine.tools.execute("get_robot_status", {}, "viewer")
    assert r["success"] and "robot" in r["result"]
    assert {t["name"] for t in engine.tools.list()} >= {"navigate_to", "detect_objects", "search_object",
                                                         "get_robot_status", "get_map", "stop_robot", "pause_task", "resume_task"}


def test_navigate_tool_result_shape(engine):
    r = engine.tools.execute("navigate_to", {"location": "Kitchen"}, "operator")
    assert r["success"] and {"destination", "distance", "estimated_time"} <= set(r["result"])
    assert r["execution_ms"] >= 0
