from backend.robotics.mapping import H, W
from backend.robotics.navigation import find_path


def test_astar_valid_path(engine):
    blocked = engine.map.static_blocked()
    r = find_path(blocked, W, H, (2, 11), (19, 10))
    assert r.success and r.path[0] == (2, 11) and r.path[-1] == (19, 10)
    assert not any(c in blocked for c in r.path)


def test_dijkstra_matches_astar_cost(engine):
    b = engine.map.static_blocked()
    a, d = find_path(b, W, H, (2, 11), (25, 15), "astar"), find_path(b, W, H, (2, 11), (25, 15), "dijkstra")
    assert abs(a.length - d.length) < 0.05 and a.nodes_expanded <= d.nodes_expanded


def test_blocked_destination(engine):
    assert not find_path(engine.map.static_blocked(), W, H, (2, 11), (10, 5)).success


def test_navigation_end_to_end(engine):
    t = engine.submit_command("Go to the reception", wait=True)
    assert t["status"] == "completed"
    assert engine.robot.cell == engine.map.find_landmark("Reception").cell
    assert engine.metrics.summary()["collision_count"] == 0


def test_obstacle_triggers_replan(engine):
    t = engine.submit_command("Go to the conference room", wait=True, options={"inject_obstacle": True})
    assert t["status"] == "completed"
    assert engine.metrics.summary()["replans"] >= 1
    assert any(e["type"] == "PATH_REPLANNED" for e in engine.audit.query())
    assert engine.safety.events and engine.metrics.summary()["collision_count"] == 0
