import pytest
from fastapi.testclient import TestClient

from backend.main import app


@pytest.fixture
def client():
    with TestClient(app) as c:
        c.post("/api/system/reset")
        yield c


def test_map_and_landmarks(client):
    assert client.get("/api/map").json()["width"] == 30
    assert any(l["name"] == "Reception" for l in client.get("/api/landmarks").json())


def test_command_roundtrip(client):
    r = client.post("/api/commands", json={"command": "Go to the reception and find a chair", "wait": True}).json()
    assert r["task_id"] == "TASK-001" and r["intent"] == "navigate_and_search" and r["status"] == "completed"
    assert client.get("/api/tasks/TASK-001").json()["result"]["status"] == "SUCCESS"
    assert client.get("/api/metrics").json()["tasks_total"] == 1
    assert client.get("/api/audit/logs", params={"type": "COMMAND_RECEIVED"}).json()


def test_invalid_command_is_validated(client):
    assert client.post("/api/commands", json={"command": ""}).status_code == 422


def test_tool_permissions_over_api(client):
    r = client.post("/api/tools/execute", json={"tool": "navigate_to", "arguments": {"location": "Kitchen"}, "role": "viewer"}).json()
    assert r["status"] == "denied"


def test_emergency_stop_endpoint(client):
    assert client.post("/api/safety/emergency-stop").json()["success"]
    assert client.get("/api/system/status").json()["estop"] is True


def test_experiments_all_pass(client):
    r = client.post("/api/experiments/run").json()
    assert r["total"] == 7 and r["passed"] == 7


def test_real_vision_rejects_unsupported_upload_type(client):
    response = client.post(
        "/api/vision/detect-image",
        files={"file": ("note.txt", b"not an image", "text/plain")},
        data={"model_type": "world"},
    )
    assert response.status_code == 415


def test_vision_object_class_guidance(client):
    response = client.get("/api/vision/object-classes")
    assert response.status_code == 200
    assert "pen" in response.json()["open_vocabulary_suggestions"]
