import os
os.environ["SIM_TICK_DELAY"] = "0"  # fast tests; must be set before backend imports
import pytest
from backend.core.engine import Engine


@pytest.fixture
def engine():
    return Engine(tick_delay=0, seed=42)
