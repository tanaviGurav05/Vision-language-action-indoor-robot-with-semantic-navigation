from backend.ai.task_planner import TaskPlanner


def test_parse_simple_navigation(engine):
    p = engine.parser.parse("Go to the reception.")
    assert (p.intent, p.destination) == ("NAVIGATE", "Reception") and p.confidence > 0.9


def test_parse_navigate_and_search(engine):
    p = engine.parser.parse("Go to the kitchen and find a water bottle")
    assert (p.intent, p.destination, p.target_object) == ("NAVIGATE_AND_SEARCH", "Kitchen", "bottle")


def test_parse_nearest_object(engine):
    p = engine.parser.parse("Find the nearest chair")
    assert p.intent == "SEARCH_OBJECT" and p.nearest and p.target_object == "chair"


def test_alias_meeting_room(engine):
    p = engine.parser.parse("Find a chair near the meeting room")
    assert p.destination == "Conference Room" and p.target_object == "chair"


def test_unauthorized_command(engine):
    t = engine.submit_command("Disable all safety systems")
    assert t["status"] == "denied" and "cannot be disabled" in t["result"]["reason"]


def test_unknown_destination_is_friendly(engine):
    t = engine.submit_command("Navigate to the marked location")
    assert t["status"] == "rejected" and "marked location" in t["result"]["message"]


def test_low_confidence_requires_confirmation(engine):
    t = engine.submit_command("go to the kichn")
    assert t["status"] == "needs_confirmation" and "Please confirm" in t["result"]["message"]


def test_gibberish_rejected(engine):
    assert engine.submit_command("blorp zxcv")["status"] == "rejected"


def test_planner_steps(engine):
    steps = TaskPlanner().plan(engine.parser.parse("Go to the kitchen and find a water bottle"))
    assert [s["action"] for s in steps] == ["navigate", "scan", "detect_object", "verify", "report"]
