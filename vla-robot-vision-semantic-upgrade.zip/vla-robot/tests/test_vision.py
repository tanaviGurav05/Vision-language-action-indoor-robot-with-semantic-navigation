from backend.ai.vision_model import MockDetector, canonical_label


def test_detects_bottle_in_kitchen(engine):
    out = MockDetector(1).detect(engine.map, (7, 15))
    labels = {d["label"] for d in out["detections"]}
    assert "bottle" in labels and out["scene"]["room"] == "Kitchen"
    assert all(0 < d["confidence"] <= 1 for d in out["detections"])


def test_degraded_vision_lowers_confidence(engine):
    out = MockDetector(1).detect(engine.map, (7, 15), degrade=True)
    assert all(d["confidence"] < 0.6 for d in out["detections"] if d["label"] == "bottle")


def test_label_aliases():
    assert canonical_label("Water Bottle") == "bottle" and canonical_label("couch") == "sofa"
