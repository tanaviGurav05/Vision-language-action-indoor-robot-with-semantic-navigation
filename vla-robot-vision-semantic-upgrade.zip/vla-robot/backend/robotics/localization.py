"""Simulated localisation: noisy pose estimate + semantic context (room, nearest landmark)."""
import math
import random


class Localizer:
    def __init__(self, sim_map, seed: int = 42, sigma: float = 0.08):
        self.map, self.sigma, self.rng = sim_map, sigma, random.Random(seed + 7)

    def estimate(self, state: dict) -> dict:
        ex = state["x"] + self.rng.gauss(0, self.sigma)
        ey = state["y"] + self.rng.gauss(0, self.sigma)
        cell = (int(round(ex)), int(round(ey)))
        lm = min(self.map.landmarks, key=lambda l: math.hypot(l.x - ex, l.y - ey))
        d = math.hypot(lm.x - ex, lm.y - ey)
        return {"x": round(ex, 2), "y": round(ey, 2), "orientation": state["orientation"],
                "room": self.map.room_of(*cell), "nearest_landmark": lm.name,
                "distance_to_landmark": round(d, 2), "confidence": round(max(0.5, 1 - self.sigma * 2), 3)}
