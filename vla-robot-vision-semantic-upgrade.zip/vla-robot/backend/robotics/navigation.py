"""A* and Dijkstra on an 8-connected grid (no corner cutting)."""
import heapq
import math
import time

from backend.robotics.interfaces import NavigationInterface, PlanResult

SQRT2 = math.sqrt(2)
DIRS = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]


def path_length(path: list) -> float:
    return round(sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(path, path[1:])), 2)


def find_path(blocked: set, width: int, height: int, start: tuple, goal: tuple,
              algorithm: str = "astar") -> PlanResult:
    t0 = time.perf_counter()
    blocked = set(blocked) - {start}
    ms = lambda: round((time.perf_counter() - t0) * 1000, 3)
    if goal in blocked or not (0 <= goal[0] < width and 0 <= goal[1] < height):
        return PlanResult(False, algorithm=algorithm, planning_ms=ms(), reason="Destination is blocked or outside the map.")
    if start == goal:
        return PlanResult(True, [start], 0.0, ms(), 0, algorithm)

    def h(c):
        if algorithm == "dijkstra":
            return 0.0
        dx, dy = abs(c[0] - goal[0]), abs(c[1] - goal[1])
        return (dx + dy) + (SQRT2 - 2) * min(dx, dy)  # octile distance

    g = {start: 0.0}; parent = {}; closed = set(); expanded = 0
    heap = [(h(start), 0.0, start)]
    while heap:
        _, cost, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        closed.add(cur); expanded += 1
        if cur == goal:
            path = [cur]
            while cur in parent:
                cur = parent[cur]; path.append(cur)
            path.reverse()
            return PlanResult(True, path, path_length(path), ms(), expanded, algorithm)
        for dx, dy in DIRS:
            nxt = (cur[0] + dx, cur[1] + dy)
            if not (0 <= nxt[0] < width and 0 <= nxt[1] < height) or nxt in blocked:
                continue
            if dx and dy and ((cur[0] + dx, cur[1]) in blocked or (cur[0], cur[1] + dy) in blocked):
                continue
            ng = cost + (SQRT2 if dx and dy else 1.0)
            if ng < g.get(nxt, float("inf")):
                g[nxt] = ng; parent[nxt] = cur
                heapq.heappush(heap, (ng + h(nxt), ng, nxt))
    return PlanResult(False, algorithm=algorithm, planning_ms=ms(), nodes_expanded=expanded,
                      reason="No collision-free path exists.")


class SimulationNavigation(NavigationInterface):
    def plan(self, blocked, width, height, start, goal, algorithm="astar") -> PlanResult:
        return find_path(blocked, width, height, start, goal, algorithm)
