"""Abstract robot/navigation interfaces: swap Simulation* for ROS2* without touching API or UI."""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from backend.core.errors import RobotDisconnectedError


@dataclass
class PlanResult:
    success: bool
    path: list = field(default_factory=list)
    length: float = 0.0
    planning_ms: float = 0.0
    nodes_expanded: int = 0
    algorithm: str = "astar"
    reason: str = ""


class RobotInterface(ABC):
    @abstractmethod
    def connected(self) -> bool: ...
    @abstractmethod
    def get_state(self) -> dict: ...
    @abstractmethod
    def move_to(self, cell: tuple) -> float: ...
    @abstractmethod
    def halt(self, status: str = "stopped") -> None: ...
    @abstractmethod
    def emergency_stop(self) -> None: ...
    @abstractmethod
    def clear_emergency_stop(self) -> None: ...


class NavigationInterface(ABC):
    @abstractmethod
    def plan(self, blocked: set, width: int, height: int, start: tuple, goal: tuple,
             algorithm: str = "astar") -> PlanResult: ...


_ROS2_MSG = ("ROS 2 bridge is not configured. Set ROBOT_MODE=simulation, or implement the rclpy "
             "bindings in ROS2Robot/ROS2Navigation (pose from /odom, goals via Nav2 NavigateToPose).")


class ROS2Robot(RobotInterface):
    """Adapter skeleton: every call reports a friendly 'disconnected' error until ROS 2 is wired in."""
    def connected(self) -> bool: return False
    def get_state(self) -> dict: raise RobotDisconnectedError(_ROS2_MSG)
    def move_to(self, cell): raise RobotDisconnectedError(_ROS2_MSG)
    def halt(self, status="stopped"): raise RobotDisconnectedError(_ROS2_MSG)
    def emergency_stop(self): raise RobotDisconnectedError(_ROS2_MSG)
    def clear_emergency_stop(self): raise RobotDisconnectedError(_ROS2_MSG)


class ROS2Navigation(NavigationInterface):
    def plan(self, blocked, width, height, start, goal, algorithm="astar"):
        raise RobotDisconnectedError(_ROS2_MSG)
