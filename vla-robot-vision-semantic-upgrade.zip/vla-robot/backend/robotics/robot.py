import math

from backend.robotics.interfaces import RobotInterface


class SimulationRobot(RobotInterface):
    """Simulated differential-drive robot. orientation: degrees, 0 = +x (east), 90 = +y (down/south)."""

    def __init__(self, start: tuple):
        self.x, self.y = float(start[0]), float(start[1])
        self.orientation = 90.0
        self.speed = 0.0
        self.battery = 100.0
        self.status = "idle"
        self.estopped = False

    @property
    def cell(self) -> tuple:
        return (int(round(self.x)), int(round(self.y)))

    def connected(self) -> bool: return True

    def get_state(self) -> dict:
        return {"x": round(self.x, 2), "y": round(self.y, 2), "orientation": round(self.orientation, 1),
                "speed": self.speed, "battery": round(self.battery, 2), "status": self.status,
                "estopped": self.estopped, "connected": True}

    def move_to(self, cell: tuple) -> float:
        dx, dy = cell[0] - self.x, cell[1] - self.y
        dist = math.hypot(dx, dy)
        if dist:
            self.orientation = math.degrees(math.atan2(dy, dx)) % 360
        self.x, self.y = float(cell[0]), float(cell[1])
        self.battery = max(0.0, self.battery - 0.05 * dist)
        self.speed, self.status = 1.0, "moving"
        return dist

    def halt(self, status: str = "stopped") -> None:
        self.speed, self.status = 0.0, status

    def emergency_stop(self) -> None:
        self.estopped = True
        self.halt("emergency_stop")

    def clear_emergency_stop(self) -> None:
        self.estopped = False
        self.halt("idle")
