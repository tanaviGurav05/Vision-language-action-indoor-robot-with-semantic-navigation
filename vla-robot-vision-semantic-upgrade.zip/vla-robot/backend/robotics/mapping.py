"""Semantic map: grid + rooms + landmarks + objects. 1 cell = 1 metre. x right, y down."""
from dataclasses import dataclass

W, H = 30, 18
ROOMS = {
    "Office": (1, 1, 9, 7), "Conference Room": (11, 1, 28, 7),
    "Lobby": (1, 9, 9, 12), "Reception": (11, 9, 28, 12),
    "Kitchen": (1, 14, 9, 16), "Storage Room": (11, 14, 19, 16), "Laboratory": (21, 14, 28, 16),
}
DOORS = {(5, 8), (15, 8), (25, 8), (5, 13), (15, 13), (25, 13), (10, 4), (10, 10), (10, 15), (20, 15)}
BOXES = [(13, 10), (18, 6), (7, 10)]  # static obstacles

LANDMARKS = [
    ("LM001", "Reception", 19, 10, "room", "Main reception area", 0.98),
    ("LM002", "Office", 5, 4, "room", "Open-plan office", 0.97),
    ("LM003", "Kitchen", 5, 15, "room", "Staff kitchen and pantry", 0.96),
    ("LM004", "Conference Room", 19, 4, "room", "Meeting and conference room", 0.97),
    ("LM005", "Laboratory", 25, 15, "room", "Robotics laboratory", 0.95),
    ("LM006", "Storage Room", 15, 15, "room", "Supplies storage", 0.94),
    ("LM007", "Lobby", 5, 11, "room", "Entrance lobby", 0.96),
    ("LM008", "Entrance", 2, 11, "entry", "Main entrance", 0.99),
    ("LM009", "Exit", 27, 10, "exit", "Emergency exit", 0.99),
]
ALIASES = {
    "Conference Room": ["meeting room", "conference room", "conference", "meeting"],
    "Laboratory": ["laboratory", "lab"], "Storage Room": ["storage room", "storage"],
    "Reception": ["reception"], "Office": ["office"], "Kitchen": ["kitchen"],
    "Lobby": ["lobby"], "Entrance": ["entrance"], "Exit": ["exit"],
}
OBJECTS = [
    ("chair", 15, 11), ("chair", 3, 3), ("chair", 17, 3), ("table", 18, 3), ("laptop", 4, 2),
    ("desk", 6, 3), ("bottle", 7, 15), ("person", 22, 11), ("fire extinguisher", 27, 16),
    ("plant", 2, 9), ("sofa", 3, 12), ("table", 4, 15),
]


@dataclass
class Landmark:
    id: str; name: str; x: int; y: int; type: str; description: str; confidence: float
    associated_objects: list

    @property
    def cell(self): return (self.x, self.y)

    def to_dict(self): return dict(self.__dict__)


class SemanticMap:
    width, height = W, H

    def __init__(self):
        self.walls = self._build_walls()
        self.boxes = set(BOXES)
        self.objects = []
        for i, (label, x, y) in enumerate(OBJECTS, 1):
            self.objects.append({"id": f"OBJ{i:03d}", "label": label, "x": x, "y": y, "room": self.room_of(x, y)})
        self.landmarks = [Landmark(i, n, x, y, t, d, c, sorted({o["label"] for o in self.objects if o["room"] == n}))
                          for i, n, x, y, t, d, c in LANDMARKS]

    @staticmethod
    def _build_walls() -> set:
        w = set()
        for x in range(W):
            w |= {(x, 0), (x, H - 1), (x, 8), (x, 13)}
        for y in range(H):
            w |= {(0, y), (W - 1, y), (10, y)}
        for y in range(13, H):
            w.add((20, y))
        return w - DOORS

    def static_blocked(self) -> set:
        return self.walls | self.boxes

    @staticmethod
    def room_of(x, y):
        for name, (x0, y0, x1, y1) in ROOMS.items():
            if x0 <= x <= x1 and y0 <= y <= y1:
                return name
        return None

    def find_landmark(self, name: str):
        key = (name or "").strip().lower()
        for lm in self.landmarks:
            if lm.name.lower() == key or key in ALIASES.get(lm.name, []):
                return lm
        return None

    def objects_in_view(self, cell, max_dist: float = 10.0) -> list:
        room = self.room_of(*cell)
        out = []
        for o in self.objects:
            d = max(abs(o["x"] - cell[0]), abs(o["y"] - cell[1]))
            if (room is not None and o["room"] == room and d <= max_dist) or d <= 2:
                out.append(o)
        return out

    def to_dict(self, dynamic: list | None = None) -> dict:
        return {"width": W, "height": H, "cell_size_m": 1.0,
                "walls": sorted([list(c) for c in self.walls]), "doors": sorted([list(c) for c in DOORS]),
                "boxes": [list(c) for c in self.boxes],
                "rooms": [{"name": n, "x0": r[0], "y0": r[1], "x1": r[2], "y1": r[3]} for n, r in ROOMS.items()],
                "landmarks": [l.to_dict() for l in self.landmarks], "objects": self.objects,
                "dynamic_obstacles": dynamic or []}
