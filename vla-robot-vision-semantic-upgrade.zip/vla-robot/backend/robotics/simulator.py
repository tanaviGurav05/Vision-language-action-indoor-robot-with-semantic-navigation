"""Dynamic world: spawns obstacles, moves walking people, provides the obstacle 'sensor'."""
import random

from backend.robotics.mapping import DOORS


class Simulator:
    def __init__(self, sim_map, seed: int = 42):
        self.map = sim_map
        self.rng = random.Random(seed)
        self.tick_count = 0
        self.dynamic: dict[str, dict] = {}
        self._pending = None
        self._n = 0

    def schedule_obstacle(self, after_ticks: int = 2, ahead: int = 4, kind: str = "box"):
        self._pending = {"tick": self.tick_count + after_ticks, "ahead": ahead, "kind": kind}

    def add_walker(self, route: list):
        if len(route) < 2:
            return
        self._n += 1
        oid = f"DYN{self._n:02d}"
        self.dynamic[oid] = {"id": oid, "kind": "person", "x": route[0][0], "y": route[0][1],
                             "route": list(route), "idx": 0, "dir": 1}

    def clear_dynamic(self):
        self.dynamic.clear(); self._pending = None

    def dynamic_cells(self) -> set:
        return {(o["x"], o["y"]) for o in self.dynamic.values()}

    def dynamic_list(self) -> list:
        return [{"id": o["id"], "kind": o["kind"], "x": o["x"], "y": o["y"]} for o in self.dynamic.values()]

    def tick(self, remaining_path: list, robot_cell: tuple) -> list:
        self.tick_count += 1
        events = []
        for o in self.dynamic.values():
            if o["kind"] != "person":
                continue
            nxt = o["idx"] + o["dir"]
            if not 0 <= nxt < len(o["route"]):
                o["dir"] *= -1; nxt = o["idx"] + o["dir"]
            cell = o["route"][nxt]
            if cell != robot_cell:
                o["idx"] = nxt; o["x"], o["y"] = cell
        p = self._pending
        if p and self.tick_count >= p["tick"] and len(remaining_path) >= 3:
            hi = len(remaining_path) - 2
            order = list(range(min(p["ahead"], hi), hi + 1)) + list(range(min(p["ahead"], hi) - 1, 0, -1))
            for k in order:
                if remaining_path[k] not in DOORS:
                    self._n += 1
                    oid = f"DYN{self._n:02d}"
                    c = remaining_path[k]
                    self.dynamic[oid] = {"id": oid, "kind": p["kind"], "x": c[0], "y": c[1]}
                    events.append({"type": "OBSTACLE_SPAWNED", "obstacle": oid, "cell": list(c), "kind": p["kind"]})
                    break
            self._pending = None
        return events

    def obstacle_ahead(self, path: list, lookahead: int = 2):
        """Distance (m) to the first dynamic obstacle on the next `lookahead` path cells, else None."""
        cells = self.dynamic_cells()
        for i, c in enumerate(path[:lookahead]):
            if c in cells:
                kind = next(o["kind"] for o in self.dynamic.values() if (o["x"], o["y"]) == c)
                return float(i + 1), kind
        return None

    def planning_blocked(self, start: tuple, goal: tuple) -> set:
        blocked = set(self.map.static_blocked())
        for (x, y) in self.dynamic_cells():  # inflate by 1 cell as a safety margin
            blocked |= {(x, y), (x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)}
        blocked.discard(start); blocked.discard(goal)
        return blocked
