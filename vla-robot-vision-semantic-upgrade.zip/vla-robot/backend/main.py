"""Run:  uvicorn backend.main:app --reload"""
import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.api import (routes_commands, routes_logs, routes_metrics, routes_navigation,
                         routes_robot, routes_tools, routes_vision)
from backend.core.errors import RobotError
from backend.core.logger import get_logger
from backend.core.state import get_engine, ws_manager

log = get_logger("main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    ws_manager.bind_loop(asyncio.get_running_loop())
    yield


app = FastAPI(title="VLA Indoor Robot - Semantic Navigation & Tool Use", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["*"], allow_headers=["*"])
for r in (routes_commands, routes_navigation, routes_vision, routes_robot, routes_tools, routes_metrics, routes_logs):
    app.include_router(r.router)


@app.exception_handler(RobotError)
async def robot_error_handler(_: Request, exc: RobotError):
    return JSONResponse(status_code=400, content=exc.to_dict())


@app.exception_handler(Exception)
async def unhandled(_: Request, exc: Exception):
    log.error(f"Unhandled error: {exc}")
    return JSONResponse(status_code=500, content={"error": "INTERNAL_ERROR",
                                                  "message": "Something went wrong, but the robot system is still running."})


@app.get("/")
def root(): return {"name": app.title, "docs": "/docs", "mode": get_engine().system_status()["mode"]}


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws_manager.connect(ws)
    try:
        await ws.send_json(get_engine().snapshot())
        while True:
            await ws.receive_text()  # keep-alive; the server pushes state/audit/task events
    except WebSocketDisconnect:
        ws_manager.disconnect(ws)
