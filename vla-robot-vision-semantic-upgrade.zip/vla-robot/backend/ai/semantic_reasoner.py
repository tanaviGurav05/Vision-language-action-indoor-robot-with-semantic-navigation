"""Tiny semantic reasoning layer: scene captions + room inference from object co-occurrence."""
ROOM_SIGNATURES = {
    "Kitchen": {"bottle", "table"}, "Office": {"laptop", "desk", "chair"},
    "Reception": {"person", "chair"}, "Laboratory": {"fire extinguisher", "laptop"},
    "Conference Room": {"table", "chair"}, "Lobby": {"sofa", "plant"},
}


def describe_scene(room, detections: list) -> str:
    labels = sorted({d["label"] for d in detections})
    seen = "I can see " + ", ".join(labels) if labels else "no recognisable objects in view"
    return f"{room or 'Unknown area'}: {seen}."


def infer_room(detections: list):
    labels = {d["label"] for d in detections}
    best, score = None, 0.0
    for room, sig in ROOM_SIGNATURES.items():
        s = len(labels & sig) / len(sig)
        if s > score:
            best, score = room, s
    return best, round(score, 2)
