"""Rule-based NLU: intent detection + entity extraction with confidence. (An LLM parser can be dropped in behind the same interface.)"""
import difflib
import re
from dataclasses import dataclass, field

from backend.ai.vision_model import OBJECT_ALIASES, canonical_label
from backend.robotics.mapping import ALIASES

NAV_VERBS = r"\b(go|move|navigate|head|drive|proceed|travel|walk|take me)\b"
SEARCH_VERBS = r"\b(find|locate|search|look for|detect|spot|check|tell me)\b"
CONTROL = [(r"^(please )?(emergency )?(stop|halt|freeze)\b", "STOP"), (r"^(please )?pause\b", "PAUSE"),
           (r"^(please )?(resume|continue)\b", "RESUME"), (r"\b(status|battery|where are you)\b", "STATUS")]


@dataclass
class ParsedCommand:
    raw: str
    intent: str = "UNKNOWN"
    destination: str | None = None
    target_object: str | None = None
    nearest: bool = False
    confidence: float = 0.0
    error: str | None = None
    reason: str | None = None
    entities: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return dict(self.__dict__)


class CommandParser:
    def __init__(self, sim_map, permissions):
        self.map, self.permissions = sim_map, permissions
        self.terms = sorted(((a, n) for n, al in ALIASES.items() for a in al), key=lambda t: -len(t[0]))
        self.single = {a: n for a, n in self.terms if " " not in a}
        self.obj_terms = sorted(OBJECT_ALIASES, key=len, reverse=True)

    def _landmark(self, t: str):
        for term, name in self.terms:
            if re.search(rf"\b{re.escape(term)}\b", t):
                return name, 0.96
        for tok in re.findall(r"[a-z]+", t):
            if len(tok) < 4 or tok in OBJECT_ALIASES:
                continue
            m = difflib.get_close_matches(tok, list(self.single), n=1, cutoff=0.78)
            if m:
                ratio = difflib.SequenceMatcher(None, tok, m[0]).ratio()
                return self.single[m[0]], round(max(0.3, 1 - (1 - ratio) * 4), 2)
        return None, 0.0

    def _object(self, t: str):
        for term in self.obj_terms:
            if re.search(rf"\b{re.escape(term)}\b", t):
                return canonical_label(term)
        return None

    def parse(self, text: str) -> ParsedCommand:
        t = text.lower().strip().rstrip(".!?")
        denied = self.permissions.screen_text(t)
        if denied:
            return ParsedCommand(text, "UNAUTHORIZED", confidence=0.99, reason=denied)
        for pattern, intent in CONTROL:
            if re.search(pattern, t):
                return ParsedCommand(text, intent, confidence=0.97)
        dest, dconf = self._landmark(t)
        obj = self._object(t)
        nearest = bool(re.search(r"\b(nearest|closest)\b", t))
        has_nav, has_search = bool(re.search(NAV_VERBS, t)), bool(re.search(SEARCH_VERBS, t))
        ent = {"destination_confidence": dconf}
        if dest and obj:
            return ParsedCommand(text, "NAVIGATE_AND_SEARCH", dest, obj, False, min(dconf, 0.95), entities=ent)
        if dest:
            return ParsedCommand(text, "NAVIGATE", dest, None, False, dconf if has_nav else min(dconf, 0.7), entities=ent)
        if obj:
            return ParsedCommand(text, "SEARCH_OBJECT", None, obj, True, 0.93 if (has_search or has_nav) else 0.6, entities=ent)
        m = re.search(r"\b(?:go|move|navigate|head|drive|proceed|travel)\s+(?:over\s+)?to\s+(?:the\s+|a\s+)?([a-z ]+?)(?:\s+and\b|$)", t)
        if m:
            cand = m.group(1).strip()
            known = ", ".join(l.name for l in self.map.landmarks)
            return ParsedCommand(text, "NAVIGATE", confidence=0.3, entities={"unresolved_destination": cand},
                                 error=f"I don't know a place called '{cand}'. Known places: {known}.")
        return ParsedCommand(text, "UNKNOWN", confidence=0.1,
                             reason="I couldn't understand that command. Try: 'Go to the kitchen and find a water bottle'.")
