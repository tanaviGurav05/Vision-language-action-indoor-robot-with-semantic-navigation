"""Vision module. MockDetector simulates a camera+detector from the world state (works on any laptop).
YoloDetector is a real Ultralytics adapter for images, used only if installed."""
import random
from datetime import datetime

from backend.ai.semantic_reasoner import describe_scene, infer_room

VOCAB = ["chair", "table", "person", "laptop", "bottle", "door", "fire extinguisher", "plant", "sofa", "desk"]
OBJECT_ALIASES = {
    "water bottle": "bottle", "bottle": "bottle", "fire extinguisher": "fire extinguisher",
    "extinguisher": "fire extinguisher", "anyone": "person", "someone": "person", "people": "person",
    "person": "person", "couch": "sofa", "sofa": "sofa", "chair": "chair", "table": "table",
    "laptop": "laptop", "monitor": "laptop", "door": "door", "plant": "plant", "desk": "desk",
}


def canonical_label(text: str) -> str:
    t = (text or "").strip().lower()
    return OBJECT_ALIASES.get(t, t)


class MockDetector:
    name = "mock-sim-detector"

    def __init__(self, seed: int = 42):
        self.rng = random.Random(seed + 1)

    def detect(self, sim_map, cell: tuple, degrade: bool = False, dynamic: list | None = None) -> dict:
        room = sim_map.room_of(*cell)
        dets = []
        sources = [(o["label"], o["x"], o["y"]) for o in sim_map.objects_in_view(cell)]
        sources += [("person", o["x"], o["y"]) for o in (dynamic or []) if o["kind"] == "person"
                    and max(abs(o["x"] - cell[0]), abs(o["y"] - cell[1])) <= 8]
        for label, x, y in sources:
            if self.rng.random() < 0.03:  # simulated miss
                continue
            conf = self.rng.gauss(0.45, 0.06) if degrade else self.rng.gauss(0.93, 0.035)
            conf = min(0.55, max(0.2, conf)) if degrade else min(0.99, max(0.75, conf))
            dx, dy = x - cell[0], y - cell[1]
            dist = max(abs(dx), abs(dy))
            size = max(28, int(110 / (1 + 0.25 * dist)))
            dets.append({"label": label, "confidence": round(conf, 3), "distance": dist,
                         "bbox": {"x": int(320 + dx * 28 - size / 2), "y": int(240 + dy * 18 - size / 2), "w": size, "h": size},
                         "world": {"x": x, "y": y}, "room": room})
        if self.rng.random() < 0.02:  # simulated false positive
            dets.append({"label": self.rng.choice(VOCAB), "confidence": round(self.rng.uniform(0.5, 0.7), 3),
                         "distance": 5, "bbox": {"x": 250, "y": 200, "w": 40, "h": 40}, "world": None, "room": room})
        for i, d in enumerate(dets, 1):
            d["id"] = f"DET{i:02d}"
        inferred, iscore = infer_room(dets)
        return {"model": self.name, "timestamp": datetime.now().isoformat(timespec="seconds"),
                "position": list(cell), "detections": dets,
                "scene": {"room": room, "caption": describe_scene(room, dets),
                          "inferred_room": inferred, "inferred_confidence": iscore}}


class YoloDetector:
    """Real image detector (pip install ultralytics). Used by POST /api/vision/detect with an uploaded image."""
    name = "yolov8n"

    def __init__(self, weights: str = "yolov8n.pt"):
        from ultralytics import YOLO  # imported lazily so the app runs without it
        self.model = YOLO(weights)

    def detect_image(self, image) -> list:
        res = self.model(image, verbose=False)[0]
        out = []
        for box, cls, conf in zip(res.boxes.xyxy.tolist(), res.boxes.cls.tolist(), res.boxes.conf.tolist()):
            x1, y1, x2, y2 = box
            out.append({"label": res.names[int(cls)], "confidence": round(float(conf), 3),
                        "bbox": {"x": int(x1), "y": int(y1), "w": int(x2 - x1), "h": int(y2 - y1)}})
        return out


def get_detector(seed: int = 42, backend: str = "mock"):
    return MockDetector(seed)  # sim world has no pixels; YoloDetector is used for uploaded images
