"""Rule-based task decomposition (deterministic fallback; an LLM planner can wrap this and fall back to it)."""


class TaskPlanner:
    def plan(self, parsed) -> list[dict]:
        i, d, o = parsed.intent, parsed.destination, parsed.target_object
        if i == "NAVIGATE":
            seq = [("navigate", d), ("verify", d), ("report", None)]
        elif i == "NAVIGATE_AND_SEARCH":
            seq = [("navigate", d), ("scan", "environment"), ("detect_object", o), ("verify", o), ("report", None)]
        elif i == "SEARCH_OBJECT":
            seq = [("navigate", f"nearest:{o}"), ("scan", "environment"), ("detect_object", o), ("verify", o), ("report", None)]
        elif i == "STOP": seq = [("stop_robot", None)]
        elif i == "PAUSE": seq = [("pause_task", None)]
        elif i == "RESUME": seq = [("resume_task", None)]
        elif i == "STATUS": seq = [("get_robot_status", None)]
        else: seq = []
        return [{"step": n, "action": a, "target": t, "status": "pending", "result": None, "duration_ms": None}
                for n, (a, t) in enumerate(seq, 1)]
