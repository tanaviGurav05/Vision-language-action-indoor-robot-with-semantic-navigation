"""Optional real-image detectors and deterministic semantic interpretation.

Standard YOLO detects its trained classes. YOLO-World supports a user-provided
open-vocabulary class list, but is still a visual detector rather than an oracle.
"""
from __future__ import annotations

from datetime import datetime
from functools import lru_cache
from io import BytesIO
from typing import Iterable

DEFAULT_OPEN_VOCAB_CLASSES = [
    "person", "water bottle", "bottle", "tea cup", "cup", "mug", "pen",
    "pencil", "paper sheet", "book", "notebook", "computer mouse", "laptop",
    "keyboard", "mobile phone", "chair", "table", "desk", "keys", "backpack",
]

ALIASES = {
    "water bottle": {"bottle", "water bottle"},
    "tea cup": {"cup", "mug", "tea cup"},
    "cup": {"cup", "mug", "tea cup"},
    "mouse": {"mouse", "computer mouse"},
    "computer mouse": {"mouse", "computer mouse"},
    "pen": {"pen", "ballpoint pen"},
    "pencil": {"pencil", "graphite pencil"},
    "paper": {"paper", "paper sheet", "document"},
    "book": {"book", "notebook"},
}


def canonical_object(label: str) -> str:
    value = (label or "").strip().lower().replace("_", " ")
    for canonical, aliases in ALIASES.items():
        if value in aliases:
            return canonical
    return value


@lru_cache(maxsize=4)
def _load_model(kind: str, weights: str):
    try:
        from ultralytics import YOLO
        if kind == "world":
            try:
                from ultralytics import YOLOWorld
            except ImportError as exc:
                raise RuntimeError(
                    "This Ultralytics version does not expose YOLOWorld. Install/update the optional vision requirements."
                ) from exc
            model = YOLOWorld(weights)
        else:
            model = YOLO(weights)
        return model
    except ImportError as exc:
        raise RuntimeError(
            "Real-image detection needs the optional vision packages. Run: python -m pip install -r requirements-vision.txt"
        ) from exc


def detect_image(image_bytes: bytes, model_type: str = "yolo", classes: Iterable[str] | None = None,
                 confidence_threshold: float = 0.25) -> dict:
    """Detect objects in an uploaded image and return normalized, explainable results."""
    try:
        from PIL import Image, UnidentifiedImageError
        image = Image.open(BytesIO(image_bytes)).convert("RGB")
    except Exception as exc:
        raise ValueError("Could not decode this image. Upload a valid JPG, PNG, or WEBP image.") from exc

    kind = "world" if model_type.lower() in {"world", "open-vocabulary", "open_vocabulary"} else "yolo"
    weights = "yolov8s-worldv2.pt" if kind == "world" else "yolov8n.pt"
    model = _load_model(kind, weights)
    requested_classes = [str(c).strip() for c in (classes or DEFAULT_OPEN_VOCAB_CLASSES) if str(c).strip()]
    if kind == "world":
        if not requested_classes:
            requested_classes = DEFAULT_OPEN_VOCAB_CLASSES
        model.set_classes(requested_classes[:80])

    results = model.predict(image, conf=max(0.05, min(float(confidence_threshold), 0.95)), verbose=False)
    result = results[0]
    names = result.names
    detections = []
    for index, box in enumerate(result.boxes):
        xyxy = box.xyxy[0].tolist()
        x1, y1, x2, y2 = [int(round(v)) for v in xyxy]
        raw_label = str(names[int(box.cls[0].item())])
        conf = float(box.conf[0].item())
        detections.append({
            "id": f"REAL-{index + 1:03d}",
            "label": raw_label,
            "canonical_label": canonical_object(raw_label),
            "confidence": round(conf, 3),
            "bbox": {"x": max(0, x1), "y": max(0, y1), "w": max(0, x2-x1), "h": max(0, y2-y1)},
            "distance": None,
            "source": "real_camera",
        })

    labels = sorted({d["canonical_label"] for d in detections})
    caption = ("I detected " + ", ".join(labels) + ".") if labels else "No objects passed the confidence threshold. Try better lighting, a closer view, or a lower threshold."
    return {
        "mode": "real_camera", "model": "YOLO-World" if kind == "world" else "YOLOv8n COCO",
        "model_type": kind, "timestamp": datetime.now().isoformat(timespec="seconds"),
        "image": {"width": image.width, "height": image.height},
        "detections": detections, "scene": {"caption": caption},
        "semantic": interpret_detections(detections),
        "notice": ("Open-vocabulary results are hypotheses; visually verify small or ambiguous objects." if kind == "world"
                   else "Standard YOLO recognizes only its trained classes; pen, pencil, paper and book are not reliable separate COCO classes."),
    }


def interpret_detections(detections: list[dict], target: str | None = None) -> dict:
    """Turn detector labels into a simple grounded summary and safe next-step suggestions."""
    target_norm = canonical_object(target or "")
    matches = []
    for d in detections:
        label = canonical_object(d.get("canonical_label") or d.get("label", ""))
        is_match = bool(target_norm and (label == target_norm or target_norm in label or label in target_norm))
        if not target_norm or is_match:
            matches.append({"label": d.get("label", label), "canonical_label": label,
                            "confidence": d.get("confidence", 0.0), "bbox": d.get("bbox"), "match": is_match if target_norm else None})
    high = [d for d in matches if float(d.get("confidence", 0)) >= 0.6]
    if target_norm:
        summary = (f"Found {len(high)} likely match(es) for '{target_norm}' in the camera image." if high
                   else f"I could not confirm '{target_norm}' above 60% confidence in this image.")
    else:
        summary = "Visible categories: " + (", ".join(sorted({d["canonical_label"] for d in matches})) if matches else "none confidently detected") + "."
    return {
        "query": target_norm or None, "summary": summary, "matches": matches,
        "evidence": [f"{d['label']} at {round(float(d.get('confidence', 0))*100)}% confidence" for d in matches],
        "recommended_next_steps": [
            "Check the bounding box and confidence before accepting the detection.",
            "If confirmed, submit a natural-language task through the existing command panel.",
            "A camera bounding box does not provide map coordinates or safe navigation distance; do not auto-drive to this object without calibrated localization.",
        ],
        "verified": bool(high),
    }
