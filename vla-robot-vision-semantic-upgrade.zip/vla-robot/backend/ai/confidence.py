import math


def combine(*scores) -> float:
    vals = [s for s in scores if s is not None]
    if not vals:
        return 0.0
    return round(math.exp(sum(math.log(max(v, 1e-6)) for v in vals) / len(vals)), 3)


def needs_confirmation(conf: float, threshold: float) -> bool:
    return conf < threshold


def band(conf: float) -> str:
    return "high" if conf >= 0.85 else "medium" if conf >= 0.6 else "low"
