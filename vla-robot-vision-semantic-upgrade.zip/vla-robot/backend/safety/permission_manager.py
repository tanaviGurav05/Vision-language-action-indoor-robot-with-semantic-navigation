import re
from enum import Enum

from backend.core.errors import UnauthorizedError


class Level(str, Enum):
    READ = "READ"
    CONTROL = "CONTROL"
    HIGH_RISK = "HIGH_RISK"
    SAFETY_STOP = "SAFETY_STOP"  # stopping can never be denied to anyone


ROLE_LEVELS = {
    "viewer": {Level.READ, Level.SAFETY_STOP},
    "operator": {Level.READ, Level.CONTROL, Level.SAFETY_STOP},
    "admin": {Level.READ, Level.CONTROL, Level.HIGH_RISK, Level.SAFETY_STOP},
}
SAFETY_BYPASS = re.compile(
    r"\b(disable|turn off|switch off|deactivate|bypass|override|ignore|remove|skip)\b.*\b(safety|e-?stop|emergency|collision|obstacle|guard|limit)", re.I)

DENY_REASON = "Safety controls cannot be disabled through standard user commands."


class PermissionManager:
    def validate_role(self, role: str) -> None:
        if role not in ROLE_LEVELS:
            raise UnauthorizedError(f"Unknown role '{role}'.")

    def check(self, role: str, level: Level) -> tuple[bool, str]:
        if role not in ROLE_LEVELS:
            return False, f"Unknown role '{role}'."
        if level in ROLE_LEVELS[role]:
            return True, "ok"
        return False, f"Role '{role}' lacks {level.value} permission."

    def screen_text(self, text: str):
        """Returns a denial reason if the text tries to weaken safety, else None."""
        return DENY_REASON if SAFETY_BYPASS.search(text) else None
