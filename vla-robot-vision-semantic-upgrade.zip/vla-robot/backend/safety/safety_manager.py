import threading
from datetime import datetime


class SafetyManager:
    """Safety always outranks speed and cannot be bypassed by the AI layers."""

    def __init__(self, audit, metrics, stop_distance: float = 2.0):
        self.audit, self.metrics, self.stop_distance = audit, metrics, stop_distance
        self.estop = False
        self.events: list[dict] = []
        self.on_event = None
        self._lock = threading.Lock()

    def record(self, event_type: str, message: str, severity: str = "warning", task_id=None, **data) -> dict:
        ev = {"id": len(self.events) + 1, "timestamp": datetime.now().isoformat(timespec="seconds"),
              "type": event_type, "severity": severity, "message": message, "task_id": task_id, "data": data}
        with self._lock:
            self.events.append(ev)
        self.metrics.record_safety_event()
        if self.on_event:
            try: self.on_event(ev)
            except Exception: pass
        self.audit.log("SAFETY_EVENT", f"{event_type}: {message}", task_id=task_id, severity=severity, **data)
        return ev

    def trigger_estop(self, reason: str = "Operator emergency stop", task_id=None):
        self.estop = True
        return self.record("EMERGENCY_STOP", reason, "critical", task_id)

    def reset_estop(self):
        self.estop = False
        self.audit.log("ESTOP_RESET", "Emergency stop cleared by authorised user", severity="warning")

    def should_stop_for_obstacle(self, distance: float) -> bool:
        return distance <= self.stop_distance

    def validate_destination(self, sim_map, cell: tuple) -> tuple[bool, str]:
        if cell in sim_map.static_blocked():
            return False, "Destination lies inside a blocked area."
        return True, "ok"

    @staticmethod
    def requires_confirmation(tool_name: str) -> bool:
        return tool_name in {"reset_emergency_stop"}
