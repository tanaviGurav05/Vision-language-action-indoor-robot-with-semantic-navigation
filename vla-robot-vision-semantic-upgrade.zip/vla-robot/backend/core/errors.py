"""Domain errors. Each carries a friendly message that is safe to show in the UI."""


class RobotError(Exception):
    code = "ROBOT_ERROR"

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message

    def to_dict(self) -> dict:
        return {"error": self.code, "message": self.message}


class InvalidCommandError(RobotError): code = "INVALID_COMMAND"
class UnknownDestinationError(RobotError): code = "UNKNOWN_DESTINATION"
class BlockedPathError(RobotError): code = "BLOCKED_PATH"
class ToolUnavailableError(RobotError): code = "TOOL_UNAVAILABLE"
class UnauthorizedError(RobotError): code = "ACCESS_DENIED"
class LowConfidenceError(RobotError): code = "LOW_CONFIDENCE"
class RobotDisconnectedError(RobotError): code = "ROBOT_DISCONNECTED"
class SafetyViolationError(RobotError): code = "SAFETY_VIOLATION"
class SimulationError(RobotError): code = "SIMULATION_ERROR"
