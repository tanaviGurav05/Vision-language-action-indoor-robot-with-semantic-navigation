"""Input sanitation. NOTE: roles are client-declared in this prototype; swap for real auth (JWT/OAuth) in production."""
import re
from backend.core.errors import InvalidCommandError

MAX_COMMAND_LENGTH = 300


def sanitize_command(text) -> str:
    if not isinstance(text, str):
        raise InvalidCommandError("Command must be text.")
    cleaned = re.sub(r"[\x00-\x1f\x7f]", " ", text)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    if not cleaned:
        raise InvalidCommandError("Please enter a command, e.g. 'Go to the kitchen and find a water bottle'.")
    if len(cleaned) > MAX_COMMAND_LENGTH:
        raise InvalidCommandError(f"Command too long (max {MAX_COMMAND_LENGTH} characters).")
    return cleaned
