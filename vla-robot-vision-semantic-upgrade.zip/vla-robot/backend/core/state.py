"""Process-wide engine singleton + WebSocket fan-out (engine runs in worker threads)."""
import asyncio

from fastapi import WebSocket

from backend.core.engine import Engine
from backend.core.logger import get_logger

log = get_logger('state')


class ConnectionManager:
    def __init__(self):
        self.connections: set[WebSocket] = set()
        self.loop = None

    def bind_loop(self, loop): self.loop = loop

    async def connect(self, ws: WebSocket):
        await ws.accept(); self.connections.add(ws)

    def disconnect(self, ws: WebSocket): self.connections.discard(ws)

    async def _broadcast(self, message: dict):
        for ws in list(self.connections):
            try: await ws.send_json(message)
            except Exception: self.connections.discard(ws)

    def broadcast_threadsafe(self, message: dict):
        if self.loop and self.connections:
            asyncio.run_coroutine_threadsafe(self._broadcast(message), self.loop)


ws_manager = ConnectionManager()
try:
    from backend.database.persistence import Persistence
    _persist = Persistence()
except Exception as e:  # DB is optional at runtime: the robot keeps working in memory
    log.warning(f"Database disabled: {e}")
    _persist = None


def _build() -> Engine:
    eng = Engine()
    eng.listeners.append(ws_manager.broadcast_threadsafe)
    if _persist:
        _persist.attach(eng)
    return eng


_engine = _build()


def get_engine() -> Engine: return _engine


def reset_engine() -> Engine:
    global _engine
    _engine.stop_robot()
    _engine = _build()
    return _engine
