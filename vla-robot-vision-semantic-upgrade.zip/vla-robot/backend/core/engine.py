"""Orchestrator: command -> parse -> plan -> tools -> navigate/vision -> verify -> report. Runs on the simulator or (later) ROS 2."""
import copy
import threading
import time
from collections import Counter
from datetime import datetime

from backend.ai.command_parser import CommandParser
from backend.ai.confidence import band
from backend.ai.task_planner import TaskPlanner
from backend.ai.vision_model import canonical_label, get_detector
from backend.core.config import settings
from backend.core.errors import BlockedPathError, SafetyViolationError, UnknownDestinationError
from backend.core.logger import get_logger
from backend.core.security import sanitize_command
from backend.monitoring.audit import AuditLogger
from backend.monitoring.metrics import MetricsEngine
from backend.robotics.localization import Localizer
from backend.robotics.mapping import DOORS, H, W, SemanticMap
from backend.robotics.navigation import SimulationNavigation, path_length
from backend.robotics.robot import SimulationRobot
from backend.robotics.simulator import Simulator
from backend.safety.permission_manager import PermissionManager
from backend.safety.safety_manager import SafetyManager
from backend.tools import navigation_tool, object_search_tool, status_tool, vision_tool
from backend.tools.tool_manager import ToolManager
from backend.verification.task_verifier import TaskVerifier

log = get_logger("engine")
NAV_INTENTS = {"NAVIGATE", "NAVIGATE_AND_SEARCH", "SEARCH_OBJECT"}
CONTROL_INTENTS = {"STOP", "PAUSE", "RESUME", "STATUS"}


class Engine:
    def __init__(self, tick_delay: float | None = None, seed: int | None = None):
        self.settings = settings
        self.tick_delay = settings.tick_delay if tick_delay is None else tick_delay
        seed = settings.seed if seed is None else seed
        self.started = time.time()
        self.audit, self.metrics = AuditLogger(), MetricsEngine()
        self.map = SemanticMap()
        self.sim = Simulator(self.map, seed)
        self.robot = SimulationRobot(self.map.find_landmark("Entrance").cell)
        self.nav = SimulationNavigation()
        self.localizer = Localizer(self.map, seed)
        self.detector = get_detector(seed, settings.vision_backend)
        self.permissions = PermissionManager()
        self.safety = SafetyManager(self.audit, self.metrics, settings.obstacle_stop_distance)
        self.verifier = TaskVerifier(settings.confidence_threshold)
        self.parser, self.planner = CommandParser(self.map, self.permissions), TaskPlanner()
        self.tools = ToolManager(self.permissions, self.audit, self.safety)
        for mod in (navigation_tool, vision_tool, object_search_tool, status_tool):
            for spec in mod.build_specs(self):
                self.tools.register(spec)
        self.tasks: dict[str, dict] = {}
        self._seq = 0
        self._lock = threading.RLock()
        self._run_lock = threading.Lock()
        self.stop_requested = threading.Event()
        self.pause_event = threading.Event(); self.pause_event.set()
        self.current_task_id = None
        self.active_options: dict = {}
        self.planned_path: list = []
        self.actual_path: list = [self.robot.cell]
        self.last_detections = None
        self.nav_state = {"status": "idle", "destination": None}
        self.listeners: list = []
        self.audit.listeners.append(lambda e: self.emit({"type": "audit", "event": e}))

    # ---------- streaming ----------
    def emit(self, message: dict):
        for fn in list(self.listeners):
            try: fn(message)
            except Exception: pass

    def snapshot(self) -> dict:
        st = self.robot.get_state()
        with self._lock:
            task = self.tasks.get(self.current_task_id)
            brief = {k: task[k] for k in ("task_id", "status", "command", "intent", "destination")} if task else None
        return {"type": "state", "mode": settings.robot_mode, "robot": st,
                "localization": self.localizer.estimate(st), "task": brief,
                "planned_path": [list(c) for c in self.planned_path], "actual_path": [list(c) for c in self.actual_path],
                "dynamic_obstacles": self.sim.dynamic_list(), "estop": self.safety.estop,
                "paused": not self.pause_event.is_set(), "tick": self.sim.tick_count,
                "navigation": dict(self.nav_state), "detections": self.last_detections}

    def emit_state(self): self.emit(self.snapshot())

    # ---------- tools' implementations ----------
    def robot_status(self) -> dict:
        st = self.robot.get_state()
        return {"robot": st, "localization": self.localizer.estimate(st), "estop": self.safety.estop,
                "paused": not self.pause_event.is_set(), "current_task": self.current_task_id, "navigation": dict(self.nav_state)}

    def stop_robot(self) -> dict:
        self.stop_requested.set(); self.pause_event.set(); self.robot.halt("stopped")
        self.audit.log("ROBOT_STOPPED", "Stop requested", task_id=self.current_task_id, severity="warning")
        return {"success": True, "message": "Robot stopped."}

    def pause_task(self) -> dict:
        if not self._busy():
            return {"success": False, "reason": "No task is currently running."}
        self.pause_event.clear(); self.robot.halt("paused")
        self.audit.log("TASK_PAUSED", "Task paused", task_id=self.current_task_id)
        return {"success": True, "message": "Task paused."}

    def resume_task(self) -> dict:
        if self.pause_event.is_set():
            return {"success": False, "reason": "Nothing is paused."}
        self.pause_event.set()
        self.audit.log("TASK_RESUMED", "Task resumed", task_id=self.current_task_id)
        return {"success": True, "message": "Task resumed."}

    def emergency_stop(self) -> dict:
        self.safety.trigger_estop(task_id=self.current_task_id)
        self.stop_requested.set(); self.pause_event.set(); self.robot.emergency_stop()
        self.emit_state()
        return {"success": True, "message": "EMERGENCY STOP engaged."}

    def reset_emergency_stop(self) -> dict:
        self.safety.reset_estop(); self.robot.clear_emergency_stop(); self.emit_state()
        return {"success": True, "message": "Emergency stop cleared."}

    def _busy(self) -> bool:
        return self._run_lock.locked()

    def detect(self) -> dict:
        cell = self.robot.cell
        out = self.detector.detect(self.map, cell, bool(self.active_options.get("degrade_vision")), self.sim.dynamic_list())
        truth = Counter(o["label"] for o in self.map.objects_in_view(cell))
        truth.update(o["kind"] for o in self.sim.dynamic_list() if o["kind"] == "person"
                     and max(abs(o["x"] - cell[0]), abs(o["y"] - cell[1])) <= 8)
        got = Counter(d["label"] for d in out["detections"])
        tp = sum((truth & got).values())
        self.metrics.record_vision(tp, sum((got - truth).values()), sum((truth - got).values()),
                                   [d["confidence"] for d in out["detections"]])
        self.last_detections = out
        self.audit.log("OBJECT_DETECTED", f'{len(out["detections"])} object(s) in {out["scene"]["room"]}',
                       task_id=self.current_task_id, labels=sorted(got))
        self.emit_state()
        return out

    def search_object(self, name: str) -> dict:
        label = canonical_label(name)
        best = None
        for _ in range(2):  # re-scan once on a miss, like a real robot would
            matches = [d for d in self.detect()["detections"] if d["label"] == label]
            if matches:
                best = max(matches, key=lambda d: d["confidence"]); break
        if not best:
            return {"success": False, "found": False, "object": label, "confidence": 0.0,
                    "reason": f"No {label} is visible from here."}
        ok = best["confidence"] >= self.settings.confidence_threshold
        res = {"success": ok, "found": True, "object": label, "confidence": best["confidence"],
               "room": best["room"], "bbox": best["bbox"]}
        if not ok:
            res["reason"] = (f"Target object could not be reliably detected "
                             f"({best['confidence']:.0%} is below the {self.settings.confidence_threshold:.0%} threshold). Please confirm.")
        return res

    def resolve_location(self, location: str):
        loc = (location or "").strip()
        if not loc:
            raise UnknownDestinationError("No destination was given.")
        if loc.lower().startswith("nearest:"):
            label = canonical_label(loc.split(":", 1)[1])
            blocked, best = self.map.static_blocked(), None
            for o in self.map.objects:
                if o["label"] != label: continue
                p = self.nav.plan(blocked, W, H, self.robot.cell, (o["x"], o["y"]))
                if p.success and (best is None or p.length < best[0]): best = (p.length, o)
            if not best:
                raise UnknownDestinationError(f"I have no known '{label}' on the map.")
            o = best[1]
            return (o["x"], o["y"]), f"nearest {label} ({o['room']})"
        lm = self.map.find_landmark(loc)
        if not lm:
            raise UnknownDestinationError(f"I don't know a place called '{loc}'. Known places: "
                                          + ", ".join(l.name for l in self.map.landmarks) + ".")
        return lm.cell, lm.name

    # ---------- navigation ----------
    def navigate(self, location: str) -> dict:
        if self.safety.estop:
            raise SafetyViolationError("Emergency stop is active. Reset it before navigating.")
        goal, name = self.resolve_location(location)
        start = self.robot.cell
        ok, why = self.safety.validate_destination(self.map, goal)
        if not ok:
            raise BlockedPathError(why)
        tid = self.current_task_id
        self.stop_requested.clear()
        plan = self.nav.plan(self.sim.planning_blocked(start, goal), W, H, start, goal)
        self.metrics.record_plan(plan.planning_ms)
        if not plan.success:
            self.audit.log("PATH_BLOCKED", plan.reason, task_id=tid, severity="warning")
            raise BlockedPathError(f"No safe path to {name}: {plan.reason}")
        optimal = self.nav.plan(self.map.static_blocked(), W, H, start, goal).length
        self.audit.log("PATH_PLANNED", f"Distance: {plan.length}m to {name} ({plan.algorithm})", task_id=tid,
                       distance=plan.length, planning_ms=plan.planning_ms, nodes=plan.nodes_expanded)
        self.planned_path = list(plan.path)
        self.actual_path = [start]
        path = plan.path[1:]
        opts = self.active_options
        if opts.get("inject_obstacle"):
            self.sim.schedule_obstacle(after_ticks=2, ahead=4)
        if opts.get("dynamic_obstacle"):
            runs, cur = [], []
            for c in plan.path[3:-1]:
                if c in DOORS:
                    if len(cur) >= 3: runs.append(cur)
                    cur = []
                else: cur.append(c)
            if len(cur) >= 3: runs.append(cur)
            if runs: self.sim.add_walker(runs[-1][:6])
        self.nav_state = {"status": "navigating", "destination": name, "distance": plan.length}
        self.audit.log("NAVIGATION_STARTED", f"Heading to {name}", task_id=tid)
        traveled, replans, collisions, ticks = 0.0, 0, 0, 0
        result = lambda success, reason="": self._nav_result(success, reason, name, goal, plan.length, traveled,
                                                              optimal, replans, collisions, ticks)
        waits = 0
        while path:
            if self.safety.estop:
                self.nav_state["status"] = "emergency_stop"; return result(False, "Emergency stop engaged.")
            if self.stop_requested.is_set():
                self.nav_state["status"] = "stopped"; return result(False, "Stopped by operator.")
            while not self.pause_event.is_set():
                if self.stop_requested.is_set() or self.safety.estop: break
                time.sleep(0.05)
            for ev in self.sim.tick(path, self.robot.cell):
                self.audit.log("OBSTACLE_APPEARED", f'{ev["kind"]} at {ev["cell"]}', task_id=tid, severity="warning")
            hit = self.sim.obstacle_ahead(path, int(self.safety.stop_distance))
            if hit:
                dist, kind = hit
                if self.safety.should_stop_for_obstacle(dist):
                    self.robot.halt("obstacle")
                    self.safety.record("OBSTACLE_TOO_CLOSE", f"{kind} {dist:.1f}m ahead - robot stopped", task_id=tid, distance=dist)
                    self.audit.log("OBSTACLE_DETECTED", f"{kind} {dist:.1f}m ahead", task_id=tid, severity="warning")
                    cur = self.robot.cell
                    np_ = self.nav.plan(self.sim.planning_blocked(cur, goal), W, H, cur, goal)
                    self.metrics.record_plan(np_.planning_ms)
                    if not np_.success:
                        waits += 1
                        if waits > 8:
                            self.nav_state["status"] = "blocked"; return result(False, "Path remained blocked; giving up safely.")
                        self.emit_state(); time.sleep(self.tick_delay); continue
                    replans += 1; waits = 0
                    if replans > 10:
                        return result(False, "Too many replans.")
                    path, self.planned_path = np_.path[1:], list(np_.path)
                    self.audit.log("PATH_REPLANNED", f"New path {np_.length}m", task_id=tid, distance=np_.length)
                    continue
            nxt = path.pop(0)
            traveled += self.robot.move_to(nxt); ticks += 1
            self.actual_path.append(nxt)
            if nxt in self.map.static_blocked() or nxt in self.sim.dynamic_cells():
                collisions += 1
                self.safety.record("COLLISION", f"Contact at {nxt}", "critical", tid)
            self.emit_state()
            if self.tick_delay: time.sleep(self.tick_delay)
        self.robot.halt("idle")
        self.nav_state = {"status": "arrived", "destination": name}
        self.audit.log("DESTINATION_REACHED", f"Arrived at {name}", task_id=tid)
        self.emit_state()
        return result(True)

    def _nav_result(self, success, reason, name, goal, dist, traveled, optimal, replans, collisions, ticks):
        return {"success": success, "destination": name, "goal": list(goal), "distance": dist,
                "estimated_time": round(dist / 1.0, 1), "path_length": round(traveled, 2), "optimal_length": optimal,
                "replans": replans, "collisions": collisions, "sim_time_s": float(ticks), "reason": reason}

    # ---------- tasks ----------
    def _new_task(self, command, parsed, role, options) -> dict:
        with self._lock:
            self._seq += 1
            tid = f"TASK-{self._seq:03d}"
            task = {"task_id": tid, "command": command, "timestamp": datetime.now().isoformat(timespec="seconds"),
                    "status": "created", "priority": "critical" if parsed.intent in CONTROL_INTENTS else "normal",
                    "role": role, "intent": parsed.intent.lower(), "destination": parsed.destination,
                    "target_object": parsed.target_object, "confidence": parsed.confidence, "parsed": parsed.to_dict(),
                    "steps": [], "execution_time_ms": None, "sim_time_s": 0, "options": options or {}, "result": None}
            self.tasks[tid] = task
        self.audit.log("TASK_CREATED", f"Task ID: {tid}", task_id=tid, intent=task["intent"])
        return task

    def _finish_task(self, task, status, result):
        task["status"], task["result"] = status, result
        self.emit({"type": "task", "task": self.get_task(task["task_id"])})
        return self.get_task(task["task_id"])

    def get_task(self, tid: str):
        with self._lock:
            return copy.deepcopy(self.tasks.get(tid))

    def list_tasks(self) -> list:
        with self._lock:
            return copy.deepcopy(list(reversed(self.tasks.values())))

    def submit_command(self, command, role="operator", execute=True, wait=True, options=None) -> dict:
        self.permissions.validate_role(role)
        command = sanitize_command(command)
        self.audit.log("COMMAND_RECEIVED", command, role=role)
        t0 = time.perf_counter()
        parsed = self.parser.parse(command)
        parse_ms = (time.perf_counter() - t0) * 1000
        task = self._new_task(command, parsed, role, options)
        tid = task["task_id"]
        self.audit.log("INTENT_RECOGNIZED", f"{parsed.intent} (confidence {parsed.confidence:.0%})", task_id=tid,
                       destination=parsed.destination, object=parsed.target_object)
        if parsed.intent == "UNAUTHORIZED":
            self.metrics.record_denied()
            self.safety.record("UNAUTHORIZED_COMMAND", f'"{command}" blocked', task_id=tid)
            self.audit.log("ACCESS_DENIED", parsed.reason, task_id=tid, severity="warning")
            return self._finish_task(task, "denied", {"status": "DENIED", "message": "ACCESS DENIED", "reason": parsed.reason, "confidence": 1.0})
        if parsed.error or parsed.intent == "UNKNOWN":
            msg = parsed.error or parsed.reason
            self.audit.log("COMMAND_REJECTED", msg, task_id=tid, severity="warning")
            return self._finish_task(task, "rejected", {"status": "REJECTED", "message": msg, "reason": msg, "confidence": parsed.confidence})
        if parsed.confidence < settings.confidence_threshold:
            what = parsed.destination or parsed.target_object
            msg = (f"I am not sufficiently confident about the detected destination ({what}, {parsed.confidence:.0%}). "
                   "Please confirm.")
            self.audit.log("LOW_CONFIDENCE", msg, task_id=tid, severity="warning")
            return self._finish_task(task, "needs_confirmation", {"status": "NEEDS_CONFIRMATION", "message": msg, "reason": msg, "confidence": parsed.confidence})
        return self._plan_and_run(task, parsed, parse_ms, execute, wait)

    def confirm_task(self, tid: str, wait: bool = False) -> dict:
        task = self.tasks.get(tid)
        if not task or task["status"] != "needs_confirmation":
            raise UnknownDestinationError("That task is not waiting for confirmation.")
        self.audit.log("CONFIRMATION_RECEIVED", "Operator confirmed", task_id=tid)
        from backend.ai.command_parser import ParsedCommand
        parsed = ParsedCommand(**task["parsed"])
        task["result"] = None
        return self._plan_and_run(task, parsed, 0.0, True, wait)

    def _plan_and_run(self, task, parsed, parse_ms, execute, wait):
        tid = task["task_id"]
        t0 = time.perf_counter()
        task["steps"] = self.planner.plan(parsed)
        self.metrics.record_plan(parse_ms + (time.perf_counter() - t0) * 1000)
        task["status"] = "planned"
        self.audit.log("TASK_PLANNED", f'{len(task["steps"])} steps', task_id=tid)
        if parsed.intent in NAV_INTENTS and self.safety.estop:
            return self._finish_task(task, "rejected", {"status": "REJECTED", "message": "Emergency stop is active.", "reason": "Reset the emergency stop first.", "confidence": 1.0})
        if not execute:
            return self.get_task(tid)
        if parsed.intent in CONTROL_INTENTS or wait:
            self.run_task(tid)
        else:
            threading.Thread(target=self.run_task, args=(tid,), daemon=True).start()
        return self.get_task(tid)

    def run_task(self, tid: str):
        task = self.tasks[tid]
        control = task["intent"].upper() in CONTROL_INTENTS
        if not control and not self._run_lock.acquire(blocking=False):
            busy = self.current_task_id
            task["status"], task["result"] = "rejected", {"status": "REJECTED", "message": f"Robot is busy with {busy}.", "reason": "Wait for the current task or stop it.", "confidence": 1.0}
            return
        try:
            if not control:
                self.current_task_id = tid
                self.active_options = dict(task["options"])
            task["status"] = "running"
            t0 = time.perf_counter()
            ctx = {"destination": None if task["parsed"]["nearest"] else task["destination"], "target": task["target_object"],
                   "expects_navigation": not control, "nav": None, "search": None}
            failed, final = False, None
            for step in task["steps"]:
                if failed and step["action"] not in ("verify", "report"):
                    step["status"] = "skipped"; continue
                if self.stop_requested.is_set() and not control:
                    failed = True
                step["status"] = "running"; s0 = time.perf_counter()
                ok, payload = self._exec_step(step, task, ctx)
                step["status"], step["result"] = ("done" if ok else "failed"), payload
                step["duration_ms"] = round((time.perf_counter() - s0) * 1000, 1)
                failed = failed or not ok
                self.emit({"type": "task", "task": self.get_task(tid)})
            ver = ctx.get("verification")
            if control:
                ok = all(s["status"] == "done" for s in task["steps"])
                res = {"status": "SUCCESS" if ok else "FAILED", "message": ctx.get("report", ""), "confidence": 1.0,
                       "reason": "" if ok else next((s["result"].get("reason", "") for s in task["steps"] if s["status"] == "failed"), "")}
            else:
                res = {"status": ver["result"] if ver else "FAILED", "confidence": ver["confidence"] if ver else 0.0,
                       "reason": ver["reason"] if ver else "Task did not complete.", "checks": ver["checks"] if ver else [],
                       "message": ctx.get("report", ""), "confidence_band": band(ver["confidence"]) if ver else "low"}
            nav = ctx.get("nav") or {}
            task["sim_time_s"] = nav.get("sim_time_s", 0)
            task["execution_time_ms"] = round((time.perf_counter() - t0) * 1000, 1)
            success = res["status"] == "SUCCESS"
            task["status"] = "completed" if success else "failed"
            task["result"] = res
            self.audit.log("TASK_COMPLETED" if success else "TASK_FAILED", res["message"] or res["reason"], task_id=tid,
                           severity="info" if success else "warning")
            if task["intent"].upper() in NAV_INTENTS:
                self._record_metrics(task, ctx, success, res)
        except Exception as e:  # never crash the app because one task failed
            task["status"] = "failed"
            task["result"] = {"status": "FAILED", "message": "Internal error while executing the task.", "reason": str(e), "confidence": 0.0}
            self.audit.log("TASK_FAILED", f"Internal error: {e}", task_id=tid, severity="error")
        finally:
            if not control:
                self.sim.clear_dynamic(); self.active_options = {}
                self.current_task_id = None
                self.nav_state = {**self.nav_state, "status": self.nav_state.get("status", "idle")}
                self._run_lock.release()
            self.emit({"type": "task", "task": self.get_task(tid)}); self.emit_state()

    def _record_metrics(self, task, ctx, success, res):
        nav = ctx.get("nav") or {}
        exists = True
        if task["target_object"]:
            exists = any(o["label"] == task["target_object"] and (task["parsed"]["nearest"] or o["room"] == task["destination"])
                         for o in self.map.objects)
        self.metrics.record_task({
            "task_id": task["task_id"], "command": task["command"], "intent": task["intent"], "success": success,
            "duration_s": nav.get("sim_time_s", 0), "nav_attempted": ctx.get("nav") is not None,
            "nav_success": bool(nav.get("success")), "path_length": nav.get("path_length", 0),
            "optimal_length": nav.get("optimal_length", 0), "collisions": nav.get("collisions", 0),
            "replans": nav.get("replans", 0), "confidence": res["confidence"], "verification_correct": success == exists})

    def _exec_step(self, step, task, ctx):
        a, role, tid = step["action"], task["role"], task["task_id"]
        if a == "navigate":
            r = self.tools.execute("navigate_to", {"location": step["target"]}, role, task_id=tid)
            ctx["nav"] = r["result"] if isinstance(r["result"], dict) else {"success": False, "reason": r["error"]}
            if r["success"]: ctx["robot_cell"] = self.robot.cell
            ctx["robot_cell"] = self.robot.cell
            return r["success"], ctx["nav"] if r["success"] else {"reason": r["error"]}
        if a == "scan":
            r = self.tools.execute("detect_objects", {}, role, task_id=tid)
            ctx["robot_cell"] = self.robot.cell
            return r["success"], ({"scene": r["result"]["scene"], "count": len(r["result"]["detections"])} if r["success"] else {"reason": r["error"]})
        if a == "detect_object":
            r = self.tools.execute("search_object", {"object_name": step["target"]}, role, task_id=tid)
            ctx["search"] = r["result"] if isinstance(r["result"], dict) else {"found": False, "reason": r["error"]}
            return r["success"], ctx["search"]
        if a == "verify":
            ctx["robot_cell"] = self.robot.cell
            v = self.verifier.verify(self.map, ctx)
            ctx["verification"] = v
            self.audit.log("TASK_VERIFIED", f'{v["result"]} ({v["confidence"]:.0%})', task_id=tid)
            return v["result"] == "SUCCESS", {"result": v["result"], "checks": v["checks"]}
        if a == "report":
            v = ctx.get("verification") or {}
            nav, s = ctx.get("nav") or {}, ctx.get("search") or {}
            if v.get("result") == "SUCCESS":
                bits = [f'Reached {nav.get("destination")}.'] if nav.get("destination") else []
                if s.get("found"): bits.append(f'Found {s["object"]} ({s["confidence"]:.0%} confidence).')
                ctx["report"] = "SUCCESS - " + " ".join(bits)
            else:
                ctx["report"] = f'FAILED - {v.get("reason", "Task could not be completed.")}'
            return True, {"message": ctx["report"]}
        r = self.tools.execute(a, {}, role, task_id=tid)  # stop_robot / pause_task / resume_task / get_robot_status
        ctx["report"] = (r["result"] or {}).get("message", "") if isinstance(r["result"], dict) else ""
        if a == "get_robot_status" and r["success"]:
            rb = r["result"]["robot"]
            ctx["report"] = f'At ({rb["x"]}, {rb["y"]}), battery {rb["battery"]}%, status {rb["status"]}.'
        return r["success"], r["result"] if r["success"] else {"reason": r["error"]}

    def system_status(self) -> dict:
        return {"mode": settings.robot_mode, "robot_connected": self.robot.connected(), "estop": self.safety.estop,
                "uptime_s": round(time.time() - self.started), "tasks": len(self.tasks),
                "ai": {"vision_model": self.detector.name, "language_model": "rule-based NLU v1",
                       "planner": "rule-based task planner", "confidence_threshold": settings.confidence_threshold},
                "busy": self._busy(), "current_task": self.current_task_id}
