"""Settings from environment variables / .env. No secrets live in source code."""
import os
from dataclasses import dataclass
from pathlib import Path


def _load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv(Path(__file__).resolve().parents[2] / ".env")


@dataclass(frozen=True)
class Settings:
    robot_mode: str = "simulation"
    tick_delay: float = 0.15
    seed: int = 42
    confidence_threshold: float = 0.6
    obstacle_stop_distance: float = 2.0
    vision_backend: str = "mock"
    database_url: str = "sqlite:///./vla_robot.db"

    @classmethod
    def load(cls) -> "Settings":
        g = os.getenv
        return cls(
            robot_mode=g("ROBOT_MODE", "simulation"),
            tick_delay=float(g("SIM_TICK_DELAY", "0.15")),
            seed=int(g("SIM_SEED", "42")),
            confidence_threshold=float(g("CONFIDENCE_THRESHOLD", "0.6")),
            obstacle_stop_distance=float(g("OBSTACLE_STOP_DISTANCE", "2.0")),
            vision_backend=g("VISION_BACKEND", "mock"),
            database_url=g("DATABASE_URL", "sqlite:///./vla_robot.db"),
        )


settings = Settings.load()
