from fastapi import APIRouter

from backend.core.state import get_engine, reset_engine

router = APIRouter(prefix="/api", tags=["robot"])


@router.get("/robot/status")
def robot_status(): return get_engine().robot_status()


@router.get("/map")
def get_map():
    e = get_engine(); return e.map.to_dict(e.sim.dynamic_list())


@router.get("/landmarks")
def landmarks(): return [l.to_dict() for l in get_engine().map.landmarks]


@router.get("/system/status")
def system_status(): return get_engine().system_status()


@router.post("/system/reset")
def system_reset():
    reset_engine(); return {"success": True, "message": "Simulation reset."}
