"""Simulated vision plus optional real-camera image inference endpoints."""
from typing import Literal

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field

from backend.ai.real_vision import DEFAULT_OPEN_VOCAB_CLASSES, detect_image, interpret_detections
from backend.core.state import get_engine

router = APIRouter(prefix="/api/vision", tags=["vision"])
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}
MAX_IMAGE_BYTES = 8 * 1024 * 1024


class InterpretRequest(BaseModel):
    detections: list[dict] = Field(default_factory=list, max_length=300)
    target: str | None = Field(default=None, max_length=80)


@router.post("/detect")
def detect():
    """Run the existing simulated detector against the simulator state."""
    return get_engine().detect()


@router.get("/object-classes")
def object_classes():
    """List suggested open-vocabulary prompts and explain standard-model limits."""
    return {
        "open_vocabulary_suggestions": DEFAULT_OPEN_VOCAB_CLASSES,
        "standard_yolo_note": "YOLOv8n COCO supports classes such as person, bottle, cup, laptop and mouse. Pen, pencil, paper and book are not reliable distinct COCO classes.",
        "open_vocabulary_note": "YOLO-World can try custom text labels, but small objects and similar categories may still be missed. Verify detections visually.",
    }


@router.post("/detect-image")
async def detect_uploaded_image(
    file: UploadFile = File(...),
    model_type: Literal["yolo", "world"] = Form("world"),
    classes: str = Form(""),
    confidence_threshold: float = Form(0.25),
):
    """Run actual model inference on one webcam frame or uploaded image."""
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(415, "Unsupported image type. Upload JPG, PNG, or WEBP.")
    content = await file.read(MAX_IMAGE_BYTES + 1)
    if not content:
        raise HTTPException(400, "The uploaded image is empty.")
    if len(content) > MAX_IMAGE_BYTES:
        raise HTTPException(413, "Image is too large. Maximum upload size is 8 MB.")
    class_list = [item.strip() for item in classes.split(",") if item.strip()] or None
    try:
        return detect_image(content, model_type=model_type, classes=class_list,
                            confidence_threshold=confidence_threshold)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(503, str(exc)) from exc
    finally:
        await file.close()


@router.post("/interpret")
def interpret(req: InterpretRequest):
    """Interpret detector evidence against an optional user-specified target."""
    return interpret_detections(req.detections, req.target)
