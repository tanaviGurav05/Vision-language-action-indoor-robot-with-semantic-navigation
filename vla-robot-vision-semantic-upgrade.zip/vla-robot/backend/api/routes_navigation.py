from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

from backend.core.state import get_engine

router = APIRouter(prefix="/api/navigation", tags=["navigation"])


class StartRequest(BaseModel):
    destination: str = Field(min_length=1, max_length=60)
    role: Literal["viewer", "operator", "admin"] = "operator"
    wait: bool = False


@router.post("/start")
def start(req: StartRequest):
    return get_engine().submit_command(f"go to the {req.destination}", req.role, True, req.wait)


@router.post("/stop")
def stop(): return get_engine().tools.execute("stop_robot", {}, "viewer")


@router.get("/status")
def status():
    e = get_engine()
    return {"navigation": e.nav_state, "planned_path": e.planned_path, "actual_path": e.actual_path,
            "robot": e.robot.get_state(), "task": e.current_task_id}
