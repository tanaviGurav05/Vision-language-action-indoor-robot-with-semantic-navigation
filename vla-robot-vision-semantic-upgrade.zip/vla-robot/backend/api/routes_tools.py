from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

from backend.core.state import get_engine

router = APIRouter(prefix="/api", tags=["tools", "safety"])


class ToolRequest(BaseModel):
    tool: str = Field(min_length=1, max_length=60)
    arguments: dict = {}
    role: Literal["viewer", "operator", "admin"] = "operator"
    confirm: bool = False


@router.get("/tools")
def list_tools(): return get_engine().tools.list()


@router.post("/tools/execute")
def execute(req: ToolRequest): return get_engine().tools.execute(req.tool, req.arguments, req.role, req.confirm)


@router.get("/tools/history")
def history(): return list(reversed(get_engine().tools.history[-100:]))


@router.post("/safety/emergency-stop")
def estop(): return get_engine().tools.execute("emergency_stop", {}, "viewer")


@router.post("/safety/reset")
def reset(role: Literal["viewer", "operator", "admin"] = "admin", confirm: bool = False):
    return get_engine().tools.execute("reset_emergency_stop", {}, role, confirm)


@router.get("/safety/events")
def events(): return list(reversed(get_engine().safety.events))
