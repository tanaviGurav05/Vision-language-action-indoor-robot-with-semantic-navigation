from fastapi import APIRouter, HTTPException

from backend.core.state import get_engine
from backend.monitoring import experiments

router = APIRouter(prefix="/api", tags=["metrics"])


@router.get("/metrics")
def metrics(): return get_engine().metrics.summary()


@router.get("/experiments/scenarios")
def scenarios(): return experiments.SCENARIOS


@router.post("/experiments/run")
def run_all(seed: int = 42): return experiments.run_all(seed)


@router.post("/experiments/run/{scenario_id}")
def run_one(scenario_id: int, seed: int = 42):
    sc = next((s for s in experiments.SCENARIOS if s["id"] == scenario_id), None)
    if not sc: raise HTTPException(404, "Unknown scenario.")
    return experiments.run_scenario(sc, seed)
