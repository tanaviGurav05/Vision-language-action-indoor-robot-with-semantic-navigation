from fastapi import APIRouter, Query

from backend.core.state import get_engine

router = APIRouter(prefix="/api/audit", tags=["audit"])


@router.get("/logs")
def logs(type: str | None = None, search: str | None = None, task_id: str | None = None,
         severity: str | None = None, limit: int = Query(200, le=1000)):
    return get_engine().audit.query(type, search, task_id, severity, limit)


@router.get("/db-counts")
def db_counts():
    try:
        from backend.database.persistence import Persistence
        return Persistence.counts()
    except Exception as e:
        return {"error": f"Database unavailable: {e}"}
