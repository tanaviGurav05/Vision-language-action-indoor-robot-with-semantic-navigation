from typing import Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from backend.core.state import get_engine

router = APIRouter(prefix="/api", tags=["commands"])


class Options(BaseModel):
    inject_obstacle: bool = False
    dynamic_obstacle: bool = False
    degrade_vision: bool = False


class CommandRequest(BaseModel):
    command: str = Field(min_length=1, max_length=300)
    role: Literal["viewer", "operator", "admin"] = "operator"
    execute: bool = True
    wait: bool = False
    options: Options = Options()


@router.post("/commands")
def post_command(req: CommandRequest):
    return get_engine().submit_command(req.command, req.role, req.execute, req.wait, req.options.model_dump())


@router.post("/tasks")
def post_task(req: CommandRequest):
    return post_command(req)


@router.get("/tasks")
def list_tasks(): return get_engine().list_tasks()


@router.get("/tasks/{task_id}")
def get_task(task_id: str):
    t = get_engine().get_task(task_id)
    if not t: raise HTTPException(404, f"Task {task_id} not found.")
    return t


@router.post("/tasks/{task_id}/confirm")
def confirm(task_id: str, wait: bool = False): return get_engine().confirm_task(task_id, wait)
