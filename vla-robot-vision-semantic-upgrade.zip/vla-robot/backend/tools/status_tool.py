from backend.safety.permission_manager import Level
from backend.tools.tool_manager import ToolSpec


def build_specs(engine):
    empty = {"type": "object", "properties": {}}
    return [
        ToolSpec("get_robot_status", "Pose, battery and task state.", empty, Level.READ,
                 lambda: {"success": True, **engine.robot_status()}),
        ToolSpec("get_map", "Semantic map with landmarks and objects.", empty, Level.READ,
                 lambda: {"success": True, "map": engine.map.to_dict(engine.sim.dynamic_list())}),
        ToolSpec("emergency_stop", "Immediately halt the robot. Always permitted.", empty, Level.SAFETY_STOP,
                 lambda: engine.emergency_stop()),
        ToolSpec("reset_emergency_stop", "Clear an emergency stop (admin + confirmation).", empty, Level.HIGH_RISK,
                 lambda: engine.reset_emergency_stop()),
    ]
