from backend.safety.permission_manager import Level
from backend.tools.tool_manager import ToolSpec


def build_specs(engine):
    return [ToolSpec("search_object", "Look for a named object at the current location.",
                     {"type": "object", "properties": {"object_name": {"type": "string"}}, "required": ["object_name"]},
                     Level.READ, lambda object_name: engine.search_object(object_name))]
