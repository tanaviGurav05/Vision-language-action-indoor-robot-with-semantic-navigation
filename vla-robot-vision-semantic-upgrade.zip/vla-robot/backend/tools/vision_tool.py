from backend.safety.permission_manager import Level
from backend.tools.tool_manager import ToolSpec


def build_specs(engine):
    return [ToolSpec("detect_objects", "Run the camera and detect objects in view.", {"type": "object", "properties": {}},
                     Level.READ, lambda: {"success": True, **engine.detect()})]
