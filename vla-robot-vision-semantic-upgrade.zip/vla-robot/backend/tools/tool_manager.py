"""Function-calling layer: schema validation, permission checks, timing and audit for every tool call."""
import time
from dataclasses import dataclass
from typing import Callable

from backend.core.errors import RobotError
from backend.safety.permission_manager import Level


@dataclass
class ToolSpec:
    name: str
    description: str
    input_schema: dict
    permission: Level
    handler: Callable


class ToolManager:
    def __init__(self, permissions, audit, safety):
        self.permissions, self.audit, self.safety = permissions, audit, safety
        self.tools: dict[str, ToolSpec] = {}
        self.history: list[dict] = []
        self.on_call = None

    def register(self, spec: ToolSpec):
        self.tools[spec.name] = spec

    def list(self) -> list[dict]:
        return [{"name": t.name, "description": t.description, "input_schema": t.input_schema,
                 "permission": t.permission.value} for t in self.tools.values()]

    def execute(self, name: str, arguments: dict | None = None, role: str = "operator",
                confirmed: bool = False, task_id=None) -> dict:
        arguments = arguments or {}
        t0 = time.perf_counter()
        call = {"task_id": task_id, "call_id": f"CALL-{len(self.history) + 1:04d}", "tool": name, "arguments": arguments, "role": role,
                "permission": None, "status": "failed", "success": False, "result": None, "error": None, "execution_ms": 0}
        spec = self.tools.get(name)
        try:
            if spec is None:
                raise RobotError(f"Tool '{name}' is not available.")
            call["permission"] = spec.permission.value
            allowed, why = self.permissions.check(role, spec.permission)
            if not allowed:
                call["status"] = "denied"
                self.safety.record("UNAUTHORIZED_TOOL", f"{name}: {why}", task_id=task_id, tool=name, role=role)
                self.audit.log("ACCESS_DENIED", f"{name} denied for {role}: {why}", task_id=task_id, severity="warning")
                call["error"] = why
                return self._finish(call, t0)
            if (self.safety.requires_confirmation(name) or spec.permission == Level.HIGH_RISK) and not confirmed:
                call["status"] = "needs_confirmation"
                call["error"] = f"'{name}' is a high-risk action and needs explicit confirmation."
                return self._finish(call, t0)
            missing = [k for k in spec.input_schema.get("required", []) if k not in arguments]
            if missing:
                raise RobotError(f"Missing required argument(s): {', '.join(missing)}.")
            result = spec.handler(**arguments)
            call["result"] = result
            call["success"] = bool(result.get("success", True)) if isinstance(result, dict) else True
            call["status"] = "success" if call["success"] else "failed"
            if not call["success"] and isinstance(result, dict):
                call["error"] = result.get("reason")
        except RobotError as e:
            call["error"] = e.message
        except Exception as e:  # one failing tool must never crash the app
            call["error"] = f"Unexpected tool error: {e}"
        return self._finish(call, t0)

    def _finish(self, call: dict, t0: float) -> dict:
        call["execution_ms"] = round((time.perf_counter() - t0) * 1000, 2)
        self.history.append(call)
        if self.on_call:
            try: self.on_call(call)
            except Exception: pass
        self.audit.log("TOOL_CALL", f'{call["tool"]} -> {call["status"]}', task_id=call["task_id"],
                       tool=call["tool"], status=call["status"], ms=call["execution_ms"])
        return call
