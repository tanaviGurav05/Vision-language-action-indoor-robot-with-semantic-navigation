from backend.safety.permission_manager import Level
from backend.tools.tool_manager import ToolSpec


def build_specs(engine):
    return [
        ToolSpec("navigate_to", "Plan and drive to a named landmark (or 'nearest:<object>').",
                 {"type": "object", "properties": {"location": {"type": "string"}}, "required": ["location"]},
                 Level.CONTROL, lambda location: engine.navigate(location)),
        ToolSpec("stop_robot", "Stop the robot and cancel current navigation.", {"type": "object", "properties": {}},
                 Level.SAFETY_STOP, lambda: engine.stop_robot()),
        ToolSpec("pause_task", "Pause the running task.", {"type": "object", "properties": {}},
                 Level.CONTROL, lambda: engine.pause_task()),
        ToolSpec("resume_task", "Resume a paused task.", {"type": "object", "properties": {}},
                 Level.CONTROL, lambda: engine.resume_task()),
    ]
