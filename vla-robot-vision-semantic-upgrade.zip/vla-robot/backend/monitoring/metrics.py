"""Metrics are computed from real simulation runs - nothing is hardcoded."""
import threading
from datetime import datetime


def _pct(num: float, den: float) -> float:
    return round(100.0 * num / den, 1) if den else 0.0


def _mean(values: list[float]) -> float:
    return round(sum(values) / len(values), 3) if values else 0.0


class MetricsEngine:
    def __init__(self):
        self._lock = threading.Lock()
        self.runs: list[dict] = []
        self.plan_latencies: list[float] = []
        self.vision = {"tp": 0, "fp": 0, "fn": 0}
        self.det_conf: list[float] = []
        self.safety_events = 0
        self.denied = 0
        self.on_run = None

    def record_plan(self, ms: float):
        with self._lock: self.plan_latencies.append(ms)

    def record_vision(self, tp: int, fp: int, fn: int, confidences: list[float]):
        with self._lock:
            self.vision["tp"] += tp; self.vision["fp"] += fp; self.vision["fn"] += fn
            self.det_conf.extend(confidences)

    def record_safety_event(self):
        with self._lock: self.safety_events += 1

    def record_denied(self):
        with self._lock: self.denied += 1

    def record_task(self, run: dict):
        run = {**run, "timestamp": datetime.now().isoformat(timespec="seconds")}
        with self._lock: self.runs.append(run)
        if self.on_run:
            try: self.on_run(run)
            except Exception: pass

    def summary(self) -> dict:
        with self._lock:
            runs = list(self.runs); v = dict(self.vision)
            lat = list(self.plan_latencies); conf = list(self.det_conf)
            safety = self.safety_events; denied = self.denied
        navs = [r for r in runs if r["nav_attempted"]]
        eff = [min(1.0, r["optimal_length"] / r["path_length"]) for r in navs
               if r["nav_success"] and r["path_length"] > 0]
        vtotal = v["tp"] + v["fp"] + v["fn"]
        return {
            "tasks_total": len(runs),
            "task_success_rate": _pct(sum(r["success"] for r in runs), len(runs)),
            "navigation_success_rate": _pct(sum(r["nav_success"] for r in navs), len(navs)),
            "collision_count": sum(r["collisions"] for r in runs),
            "replans": sum(r["replans"] for r in runs),
            "avg_completion_time_s": _mean([r["duration_s"] for r in runs]),
            "path_efficiency": round(100 * _mean(eff), 1),
            "planning_latency_ms": _mean(lat),
            "vision_accuracy": _pct(v["tp"], vtotal),
            "avg_detection_confidence": round(100 * _mean(conf), 1),
            "verification_accuracy": _pct(sum(r["verification_correct"] for r in runs), len(runs)),
            "safety_events": safety,
            "denied_requests": denied,
            "history": runs[-50:],
        }
