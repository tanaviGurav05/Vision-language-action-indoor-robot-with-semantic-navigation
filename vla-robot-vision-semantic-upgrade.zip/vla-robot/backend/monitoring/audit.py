"""Audit trail: every important event is timestamped, stored and streamed to listeners."""
import threading
from datetime import datetime

from backend.core.logger import get_logger

log = get_logger("audit")


class AuditLogger:
    def __init__(self, max_events: int = 5000):
        self._events: list[dict] = []
        self._lock = threading.Lock()
        self._seq = 0
        self.max_events = max_events
        self.listeners: list = []

    def log(self, event_type: str, message: str = "", task_id: str | None = None,
            severity: str = "info", **data) -> dict:
        now = datetime.now()
        with self._lock:
            self._seq += 1
            event = {"id": self._seq, "timestamp": now.isoformat(timespec="milliseconds"),
                     "time": now.strftime("%H:%M:%S"), "type": event_type, "message": message,
                     "task_id": task_id, "severity": severity, "data": data}
            self._events.append(event)
            if len(self._events) > self.max_events:
                self._events = self._events[-self.max_events:]
        log.info(f"{event_type} {message}")
        for fn in list(self.listeners):
            try:
                fn(event)
            except Exception:  # a broken listener must never break the robot
                pass
        return event

    def query(self, event_type: str | None = None, search: str | None = None,
              task_id: str | None = None, severity: str | None = None, limit: int = 200) -> list[dict]:
        with self._lock:
            events = list(self._events)
        out = []
        for e in reversed(events):
            if event_type and e["type"] != event_type: continue
            if task_id and e["task_id"] != task_id: continue
            if severity and e["severity"] != severity: continue
            if search and search.lower() not in f'{e["type"]} {e["message"]} {e["data"]}'.lower(): continue
            out.append(e)
            if len(out) >= limit: break
        return out
