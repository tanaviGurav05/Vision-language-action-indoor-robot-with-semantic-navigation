from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend.core.config import settings
from backend.database.models import Base

_kwargs = {"connect_args": {"check_same_thread": False}} if settings.database_url.startswith("sqlite") else {}
db_engine = create_engine(settings.database_url, **_kwargs)
SessionLocal = sessionmaker(bind=db_engine, expire_on_commit=False)


def init_db() -> None:
    Base.metadata.create_all(db_engine)


@contextmanager
def session_scope():
    s = SessionLocal()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()
