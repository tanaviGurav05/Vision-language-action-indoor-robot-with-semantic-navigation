"""Writes audit logs, tasks, tool calls, safety events and runs to SQLite. A DB failure never stops the robot."""
from datetime import datetime

from sqlalchemy import func, select

from backend.core.logger import get_logger
from backend.database import models as m
from backend.database.database import init_db, session_scope

log = get_logger("db")
FINAL = {"completed", "failed", "denied", "rejected", "needs_confirmation"}


class Persistence:
    def __init__(self):
        init_db()

    def _write(self, fn):
        try:
            with session_scope() as s:
                fn(s)
        except Exception as e:
            log.warning(f"DB write skipped: {e}")

    def attach(self, engine):
        self._write(lambda s: self._seed(s, engine))
        engine.audit.listeners.append(self.save_audit)
        engine.listeners.append(self.on_message)
        engine.tools.on_call = self.save_tool_call
        engine.safety.on_event = self.save_safety
        engine.metrics.on_run = self.save_run

    @staticmethod
    def _seed(s, engine):
        for name, role in (("viewer", "viewer"), ("operator", "operator"), ("admin", "admin")):
            if not s.scalar(select(m.User).where(m.User.username == name)):
                s.add(m.User(username=name, role=role))
        if not s.scalar(select(m.Robot)):
            s.add(m.Robot(name="VLA-Bot-01", mode=engine.settings.robot_mode))
        for lm in engine.map.landmarks:
            s.merge(m.LandmarkRow(id=lm.id, name=lm.name, x=lm.x, y=lm.y, type=lm.type,
                                  description=lm.description, confidence=lm.confidence))
        for o in engine.map.objects:
            s.merge(m.ObjectRow(id=o["id"], label=o["label"], x=o["x"], y=o["y"], room=o["room"]))

    def save_audit(self, e: dict):
        self._write(lambda s: s.add(m.AuditLog(timestamp=e["timestamp"], type=e["type"], message=e["message"],
                                               task_id=e["task_id"], severity=e["severity"], data=e["data"])))

    def save_tool_call(self, c: dict):
        self._write(lambda s: s.add(m.ToolCall(call_id=c["call_id"], task_id=c.get("task_id"), tool=c["tool"], role=c["role"],
                                               status=c["status"], execution_ms=c["execution_ms"],
                                               arguments=c["arguments"], error=c["error"])))

    def save_safety(self, ev: dict):
        self._write(lambda s: s.add(m.SafetyEventRow(timestamp=ev["timestamp"], type=ev["type"], severity=ev["severity"],
                                                     message=ev["message"], task_id=ev["task_id"])))

    def save_run(self, r: dict):
        def fn(s):
            s.add(m.NavigationRun(task_id=r["task_id"], path_length=r["path_length"], optimal_length=r["optimal_length"],
                                  replans=r["replans"], collisions=r["collisions"], success=r["nav_success"]))
            for name in ("duration_s", "confidence", "path_length", "replans"):
                s.add(m.MetricRow(task_id=r["task_id"], name=name, value=float(r[name])))
        self._write(fn)

    def on_message(self, msg: dict):
        if msg.get("type") != "task" or msg["task"]["status"] not in FINAL:
            return
        t = msg["task"]

        def fn(s):
            s.merge(m.Task(task_id=t["task_id"], command=t["command"], intent=t["intent"], status=t["status"],
                           priority=t["priority"], role=t["role"], confidence=t["confidence"],
                           execution_time_ms=t["execution_time_ms"], result=t["result"],
                           created_at=datetime.fromisoformat(t["timestamp"])))
            s.flush()
            for old in s.scalars(select(m.TaskStep).where(m.TaskStep.task_id == t["task_id"])):
                s.delete(old)
            for st in t["steps"]:
                s.add(m.TaskStep(task_id=t["task_id"], step=st["step"], action=st["action"], target=st["target"],
                                 status=st["status"], duration_ms=st["duration_ms"], result=st["result"]))
        self._write(fn)

    @staticmethod
    def counts() -> dict:
        out = {}
        try:
            with session_scope() as s:
                for model in (m.User, m.Robot, m.Task, m.TaskStep, m.LandmarkRow, m.ObjectRow, m.NavigationRun,
                              m.ToolCall, m.AuditLog, m.SafetyEventRow, m.MetricRow):
                    out[model.__tablename__] = s.scalar(select(func.count()).select_from(model))
        except Exception as e:
            return {"error": f"Database unavailable: {e}"}
        return out
