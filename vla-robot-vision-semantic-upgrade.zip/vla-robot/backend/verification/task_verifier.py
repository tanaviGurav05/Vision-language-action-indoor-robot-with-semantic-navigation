import math

from backend.ai.confidence import combine


class TaskVerifier:
    def __init__(self, threshold: float = 0.6):
        self.threshold = threshold

    def verify(self, sim_map, ctx: dict) -> dict:
        checks, confs = [], []
        nav, search = ctx.get("nav"), ctx.get("search")
        if ctx.get("expects_navigation", True):
            ok = bool(nav and nav.get("success"))
            checks.append({"check": "Navigation completed", "passed": ok,
                           "detail": "" if ok else (nav or {}).get("reason", "Navigation did not complete.")})
            confs.append(1.0 if ok else 0.0)
        dest = ctx.get("destination")
        if dest:
            lm = sim_map.find_landmark(dest)
            cell = ctx["robot_cell"]
            reached = bool(lm) and (sim_map.room_of(*cell) == sim_map.room_of(*lm.cell)
                                    or math.hypot(cell[0] - lm.x, cell[1] - lm.y) <= 1.5)
            checks.append({"check": f"{dest} reached", "passed": reached, "detail": "" if reached else f"Robot is not at {dest}."})
            confs.append(1.0 if reached else 0.0)
        target = ctx.get("target")
        if target:
            found = bool(search and search.get("found"))
            conf = (search or {}).get("confidence") or 0.0
            reliable = found and conf >= self.threshold
            checks.append({"check": f"{target} detected", "passed": reliable,
                           "detail": "" if reliable else (search or {}).get("reason", "Target object could not be reliably detected.")})
            if found:
                confs.append(conf)
        failed = [c for c in checks if not c["passed"]]
        return {"result": "FAILED" if failed else "SUCCESS", "checks": checks,
                "reason": failed[0]["detail"] or failed[0]["check"] + " failed" if failed else "All checks passed.",
                "confidence": (round(min(confs), 3) if confs else 0.0) if failed else (combine(*confs) if confs else 1.0)}
