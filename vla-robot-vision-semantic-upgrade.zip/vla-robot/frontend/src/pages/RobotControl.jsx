import { Pause, Play, Square } from 'lucide-react'
import { Card, Page, Stat } from '../components/ui.jsx'
import { api } from '../services/api.js'
import { useRobot } from '../hooks/useRobot.jsx'

export default function RobotControl() {
  const { state, map, role, notify } = useRobot()
  const r = state?.robot, loc = state?.localization
  const call = async (tool) => {
    const res = await api('/tools/execute', { method: 'POST', body: { tool, role } }).catch((e) => ({ error: e.message }))
    notify(res.error || (res.success ? res.result?.message || 'Done' : `${res.status}: ${res.error || ''}`), res.success ? 'info' : 'error')
  }
  const go = (name) => api('/commands', { method: 'POST', body: { command: `Go to the ${name}`, role } }).then((t) => notify(`${t.task_id}: ${t.status}`)).catch((e) => notify(e.message, 'error'))
  return (
    <Page title="Robot Control" subtitle={`Acting as role: ${role} (change in Settings)`}>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Telemetry">
          <div className="grid grid-cols-3 gap-4">
            <Stat label="X" value={r?.x} /><Stat label="Y" value={r?.y} /><Stat label="Heading" value={r ? `${r.orientation}°` : '-'} />
            <Stat label="Speed" value={r ? `${r.speed} m/s` : '-'} /><Stat label="Status" value={r?.status} /><Stat label="Tick" value={state?.tick} />
          </div>
          <div className="mt-4">
            <div className="mb-1 flex justify-between text-xs text-slate-500"><span>Battery</span><span>{r?.battery?.toFixed(1)}%</span></div>
            <div className="h-2.5 overflow-hidden rounded-full bg-slate-200 dark:bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-cyan-400 transition-all" style={{ width: `${r?.battery || 0}%` }} /></div>
          </div>
          <div className="mt-4 rounded-xl bg-slate-100 p-3 text-xs dark:bg-white/5">
            <div className="mb-1 font-semibold">Localization estimate (noisy)</div>
            {loc ? <div className="font-mono">({loc.x}, {loc.y}) | {loc.room || 'corridor'} | nearest: {loc.nearest_landmark} ({loc.distance_to_landmark} m) | conf {(loc.confidence * 100).toFixed(0)}%</div> : '-'}
          </div>
        </Card>
        <Card title="Controls">
          <div className="flex flex-wrap gap-2">
            <button className="btn-primary" onClick={() => call('pause_task')}><Pause size={16} />Pause</button>
            <button className="btn-primary" onClick={() => call('resume_task')}><Play size={16} />Resume</button>
            <button className="btn bg-amber-500 text-white hover:bg-amber-400" onClick={() => call('stop_robot')}><Square size={16} />Stop</button>
          </div>
          <h4 className="mb-2 mt-5 text-xs font-semibold uppercase text-slate-500">Quick destinations</h4>
          <div className="flex flex-wrap gap-2">{map?.landmarks.map((l) => <button key={l.id} className="btn-ghost" onClick={() => go(l.name.toLowerCase())}>{l.name}</button>)}</div>
        </Card>
      </div>
    </Page>
  )
}
