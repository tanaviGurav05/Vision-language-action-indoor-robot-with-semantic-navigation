import { useState } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { FlaskConical } from 'lucide-react'
import { Badge, Card, Page, Stat, Table } from '../components/ui.jsx'
import { usePoll } from '../hooks/usePoll.js'
import { api } from '../services/api.js'
import { useRobot } from '../hooks/useRobot.jsx'

export default function Metrics() {
  const { notify } = useRobot()
  const [m] = usePoll('/metrics')
  const [exp, setExp] = useState(null)
  const [busy, setBusy] = useState(false)
  const run = async () => { setBusy(true); try { setExp(await api('/experiments/run', { method: 'POST' })) } catch (e) { notify(e.message, 'error') } finally { setBusy(false) } }
  const hist = (m?.history || []).map((h, i) => ({ n: i + 1, time: h.duration_s, replans: h.replans, conf: +(h.confidence * 100).toFixed(1) }))
  const tip = { contentStyle: { background: '#0f172a', border: 'none', borderRadius: 12, color: '#e2e8f0' } }
  const cards = m && [
    ['Task success', `${m.task_success_rate}%`], ['Navigation success', `${m.navigation_success_rate}%`], ['Collisions', m.collision_count], ['Avg completion', `${m.avg_completion_time_s}s`],
    ['Path efficiency', `${m.path_efficiency}%`], ['Planning latency', `${m.planning_latency_ms} ms`], ['Vision accuracy', `${m.vision_accuracy}%`], ['Detection conf.', `${m.avg_detection_confidence}%`],
    ['Verification acc.', `${m.verification_accuracy}%`], ['Safety events', m.safety_events],
  ]
  return (
    <Page title="Metrics & Experiments" subtitle="All values are computed from actual simulation runs.">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        {(cards || []).map(([l, v]) => <Card key={l}><Stat label={l} value={v} /></Card>)}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Completion time & replans per task">
          <ResponsiveContainer width="100%" height={220}><LineChart data={hist}><CartesianGrid strokeDasharray="3 3" opacity={0.15} /><XAxis dataKey="n" fontSize={11} /><YAxis fontSize={11} /><Tooltip {...tip} /><Legend /><Line dataKey="time" stroke="#6366f1" strokeWidth={2} /><Line dataKey="replans" stroke="#f59e0b" strokeWidth={2} /></LineChart></ResponsiveContainer>
        </Card>
        <Card title="Result confidence per task (%)">
          <ResponsiveContainer width="100%" height={220}><BarChart data={hist}><CartesianGrid strokeDasharray="3 3" opacity={0.15} /><XAxis dataKey="n" fontSize={11} /><YAxis fontSize={11} domain={[0, 100]} /><Tooltip {...tip} /><Bar dataKey="conf" fill="#22d3ee" radius={4} /></BarChart></ResponsiveContainer>
        </Card>
      </div>
      <Card title="Experiments (7 scenarios, isolated simulators)" icon={FlaskConical} right={<button className="btn-primary" onClick={run} disabled={busy}>{busy ? 'Running...' : 'Run all scenarios'}</button>}>
        {exp ? (<>
          <p className="mb-2 text-sm">Passed <b>{exp.passed}/{exp.total}</b> scenarios (pass = the system behaved as expected, including correct refusals).</p>
          <Table head={['#', 'Scenario', 'Expected', 'Actual', 'Pass', 'Success', 'Time', 'Collisions', 'Replans', 'Confidence']}>
            {exp.results.map((r) => <tr key={r.id}><td className="td">{r.id}</td><td className="td">{r.scenario}</td><td className="td text-xs">{r.expected}</td><td className="td text-xs">{r.actual}</td>
              <td className="td"><Badge tone={r.passed ? 'green' : 'red'}>{r.passed ? 'PASS' : 'FAIL'}</Badge></td><td className="td">{r.success ? 'Yes' : 'No'}</td><td className="td">{r.time_s}s</td><td className="td">{r.collisions}</td><td className="td">{r.replans}</td><td className="td">{r.confidence}%</td></tr>)}
          </Table>
        </>) : <p className="text-sm text-slate-500">Click "Run all scenarios" to generate the results table.</p>}
      </Card>
    </Page>
  )
}
