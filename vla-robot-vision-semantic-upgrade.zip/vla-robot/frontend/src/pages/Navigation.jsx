import { useState } from 'react'
import { Badge, Card, Page, Stat } from '../components/ui.jsx'
import RobotMap from '../components/RobotMap.jsx'
import { usePoll } from '../hooks/usePoll.js'
import { api } from '../services/api.js'
import { useRobot } from '../hooks/useRobot.jsx'

const len = (p) => (p || []).slice(1).reduce((s, c, i) => s + Math.hypot(c[0] - p[i][0], c[1] - p[i][1]), 0)

export default function NavigationPage() {
  const { state, map, role, notify } = useRobot()
  const [dest, setDest] = useState('Reception')
  const [m] = usePoll('/metrics')
  const go = () => api('/navigation/start', { method: 'POST', body: { destination: dest, role } }).then((t) => notify(`${t.task_id}: ${t.status}`)).catch((e) => notify(e.message, 'error'))
  const nav = state?.navigation || {}
  return (
    <Page title="Navigation" subtitle="A* planner on an 8-connected grid; replans around dynamic obstacles.">
      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Start navigation">
          <select className="input" value={dest} onChange={(e) => setDest(e.target.value)}>{map?.landmarks.map((l) => <option key={l.id}>{l.name}</option>)}</select>
          <button className="btn-primary mt-3" onClick={go}>Navigate</button>
        </Card>
        <Card title="Status"><div className="grid grid-cols-2 gap-3"><Stat label="State" value={nav.status || 'idle'} /><Stat label="Destination" value={nav.destination || '-'} /><Stat label="Planned length" value={`${len(state?.planned_path).toFixed(1)} m`} /><Stat label="Actual length" value={`${len(state?.actual_path).toFixed(1)} m`} /></div></Card>
        <Card title="Planner stats"><div className="grid grid-cols-2 gap-3"><Stat label="Replans" value={m?.replans} /><Stat label="Path efficiency" value={m ? `${m.path_efficiency}%` : '-'} /><Stat label="Nav. success" value={m ? `${m.navigation_success_rate}%` : '-'} /><Stat label="Plan latency" value={m ? `${m.planning_latency_ms} ms` : '-'} /></div><div className="mt-3"><Badge tone="indigo">algorithm: A* (Dijkstra available)</Badge></div></Card>
      </div>
      <Card><RobotMap height={480} /></Card>
    </Page>
  )
}
