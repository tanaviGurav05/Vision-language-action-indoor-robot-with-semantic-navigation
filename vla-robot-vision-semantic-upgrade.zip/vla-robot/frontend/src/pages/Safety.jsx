import { useState } from 'react'
import { AlertTriangle, ShieldCheck } from 'lucide-react'
import { Badge, Card, Page, Table } from '../components/ui.jsx'
import { usePoll } from '../hooks/usePoll.js'
import { api } from '../services/api.js'
import { useRobot } from '../hooks/useRobot.jsx'

const RULES = ['Emergency stop is always available to every role', 'Robot stops when an obstacle is within 2 m', 'Navigation never enters blocked cells',
  'Unauthorized or safety-weakening commands are denied and logged', 'High-risk actions need admin role + explicit confirmation', 'AI layers cannot bypass the safety manager']

export default function Safety() {
  const { state, role, notify } = useRobot()
  const [events, reload] = usePoll('/safety/events', null, 2000)
  const [confirm, setConfirm] = useState(false)
  const estop = () => api('/safety/emergency-stop', { method: 'POST' }).then(() => { notify('EMERGENCY STOP engaged', 'error'); reload() }).catch((e) => notify(e.message, 'error'))
  const reset = async () => {
    const r = await api('/safety/reset', { method: 'POST', params: { role, confirm } }).catch((e) => ({ error: e.message }))
    notify(r.error || (r.success ? 'E-stop cleared' : r.error || `${r.status}: ${r.error}`), r.success ? 'info' : 'error'); reload()
  }
  return (
    <Page title="Safety" subtitle="Safety always outranks speed and cannot be bypassed by the AI pipeline.">
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className={state?.estop ? '!border-rose-500/60' : ''}>
          <div className="flex items-center gap-3">
            {state?.estop ? <AlertTriangle className="text-rose-500" size={32} /> : <ShieldCheck className="text-emerald-500" size={32} />}
            <div><div className="text-lg font-semibold">{state?.estop ? 'EMERGENCY STOP ACTIVE' : 'Systems nominal'}</div><div className="text-xs text-slate-500">Role: {role}</div></div>
          </div>
          <button onClick={estop} className="btn mt-4 w-full justify-center bg-rose-600 py-4 text-lg font-extrabold tracking-widest text-white shadow-xl shadow-rose-600/40 hover:bg-rose-500">EMERGENCY STOP</button>
          <div className="mt-4 border-t border-slate-200 pt-3 dark:border-white/10">
            <label className="mb-2 flex items-center gap-2 text-sm"><input type="checkbox" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} />I confirm clearing the e-stop</label>
            <button className="btn-ghost" onClick={reset}>Reset e-stop (admin)</button>
          </div>
        </Card>
        <Card title="Safety rules" className="lg:col-span-2"><ul className="space-y-1.5 text-sm">{RULES.map((r) => <li key={r} className="flex gap-2"><ShieldCheck size={16} className="mt-0.5 shrink-0 text-emerald-500" />{r}</li>)}</ul></Card>
      </div>
      <Card title="Safety event log">
        <Table head={['Time', 'Type', 'Severity', 'Message', 'Task']}>
          {(events || []).map((e) => <tr key={e.id}><td className="td font-mono text-xs">{e.timestamp.slice(11)}</td><td className="td">{e.type}</td><td className="td"><Badge tone={e.severity === 'critical' ? 'red' : 'amber'}>{e.severity}</Badge></td><td className="td">{e.message}</td><td className="td font-mono text-xs">{e.task_id}</td></tr>)}
        </Table>
        {events?.length === 0 && <p className="p-3 text-sm text-slate-500">No safety events.</p>}
      </Card>
    </Page>
  )
}
