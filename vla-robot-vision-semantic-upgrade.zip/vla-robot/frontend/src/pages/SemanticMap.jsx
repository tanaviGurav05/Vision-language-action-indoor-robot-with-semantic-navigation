import { useState } from 'react'
import { Navigation, Square } from 'lucide-react'
import { Badge, Card, Page } from '../components/ui.jsx'
import RobotMap from '../components/RobotMap.jsx'
import { api } from '../services/api.js'
import { useRobot } from '../hooks/useRobot.jsx'

export default function SemanticMap() {
  const { role, notify } = useRobot()
  const [sel, setSel] = useState(null)
  const start = () => api('/commands', { method: 'POST', body: { command: `Go to the ${sel.name}`, role } }).then((t) => notify(`${t.task_id}: ${t.status}`)).catch((e) => notify(e.message, 'error'))
  const stop = () => api('/navigation/stop', { method: 'POST' }).then(() => notify('Robot stopped')).catch((e) => notify(e.message, 'error'))
  return (
    <Page title="Semantic Map" subtitle="Scroll to zoom, drag to pan, click a landmark to select a destination.">
      <div className="grid gap-4 xl:grid-cols-4">
        <Card className="xl:col-span-3"><RobotMap selected={sel} onSelect={setSel} height={600} /></Card>
        <Card title="Destination">
          {sel ? (<div className="space-y-2 text-sm">
            <div className="text-lg font-semibold">{sel.name}</div><Badge tone="indigo">{sel.type}</Badge>
            <p className="text-slate-500">{sel.description}</p>
            <p className="font-mono text-xs">({sel.x}, {sel.y}) | confidence {(sel.confidence * 100).toFixed(0)}%</p>
            <p className="text-xs text-slate-500">Objects: {sel.associated_objects.join(', ') || 'none'}</p>
            <div className="flex gap-2 pt-2"><button className="btn-primary" onClick={start}><Navigation size={16} />Start</button><button className="btn bg-amber-500 text-white" onClick={stop}><Square size={16} />Stop</button></div>
          </div>) : <p className="text-sm text-slate-500">No landmark selected.</p>}
        </Card>
      </div>
    </Page>
  )
}
