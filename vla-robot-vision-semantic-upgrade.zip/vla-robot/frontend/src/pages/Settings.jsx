import { Badge, Card, Page } from '../components/ui.jsx'
import { usePoll } from '../hooks/usePoll.js'
import { api } from '../services/api.js'
import { useRobot } from '../hooks/useRobot.jsx'

export default function Settings() {
  const { theme, setTheme, role, setRole, connected, notify, loadMap } = useRobot()
  const [sys] = usePoll('/system/status', null, 5000)
  const reset = async () => { try { await api('/system/reset', { method: 'POST' }); await loadMap(); notify('Simulation reset') } catch (e) { notify(e.message, 'error') } }
  return (
    <Page title="Settings">
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Preferences">
          <label className="mb-3 block text-sm">Theme
            <select className="input mt-1" value={theme} onChange={(e) => setTheme(e.target.value)}><option value="dark">Dark</option><option value="light">Light</option></select></label>
          <label className="block text-sm">Acting role (demo only - replace with real auth in production)
            <select className="input mt-1" value={role} onChange={(e) => setRole(e.target.value)}><option>viewer</option><option>operator</option><option>admin</option></select></label>
        </Card>
        <Card title="System">
          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between"><span>WebSocket</span><Badge tone={connected ? 'green' : 'red'}>{connected ? 'connected' : 'disconnected'}</Badge></div>
            <div className="flex justify-between"><span>Mode</span><span>{sys?.mode}</span></div>
            <div className="flex justify-between"><span>Uptime</span><span>{sys?.uptime_s}s</span></div>
            <div className="flex justify-between"><span>Tasks</span><span>{sys?.tasks}</span></div>
          </div>
          <button className="btn-ghost mt-4" onClick={reset}>Reset simulation</button>
          <p className="mt-3 text-xs text-slate-500">Real-robot mode: implement ROS2Robot / ROS2Navigation (see docs/ros2.md) and set ROBOT_MODE=ros2.</p>
        </Card>
      </div>
    </Page>
  )
}
