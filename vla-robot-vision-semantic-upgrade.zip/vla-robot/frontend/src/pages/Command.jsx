import { useState } from 'react'
import { Send } from 'lucide-react'
import { Badge, Card, Page, statusTone } from '../components/ui.jsx'
import Pipeline from '../components/Pipeline.jsx'
import { api } from '../services/api.js'
import { useRobot } from '../hooks/useRobot.jsx'

const EXAMPLES = ['Go to the reception', 'Find the nearest chair', 'Go to the kitchen and find a water bottle', 'Move to the conference room',
  'Find the fire extinguisher', 'Go to the reception and tell me if anyone is there', 'Navigate to the marked location', 'Disable all safety systems']

export default function Command() {
  const { task, setTask, role, events, notify } = useRobot()
  const [text, setText] = useState('Go to the kitchen and find a water bottle')
  const [opts, setOpts] = useState({ inject_obstacle: false, dynamic_obstacle: false, degrade_vision: false })
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault(); setBusy(true)
    try { setTask(await api('/commands', { method: 'POST', body: { command: text, role, options: opts } })) }
    catch (err) { notify(err.message, 'error') } finally { setBusy(false) }
  }
  const confirm = () => api(`/tasks/${task.task_id}/confirm`, { method: 'POST' }).then(setTask).catch((e) => notify(e.message, 'error'))
  const myEvents = events.filter((e) => task && e.task_id === task.task_id).slice(0, 25)

  return (
    <Page title="Natural Language Command" subtitle="Command -> parser -> intent -> entities -> planner -> tools -> navigation -> vision -> verification -> response">
      <Card>
        <form onSubmit={submit} className="space-y-3">
          <div className="flex gap-2">
            <input className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="e.g. Go to the kitchen and find a water bottle" maxLength={300} />
            <button className="btn-primary" disabled={busy}><Send size={16} />Send</button>
          </div>
          <div className="flex flex-wrap gap-1.5">{EXAMPLES.map((x) => <button type="button" key={x} onClick={() => setText(x)} className="rounded-full border border-slate-300 px-2.5 py-1 text-xs hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/10">{x}</button>)}</div>
          <div className="flex flex-wrap gap-4 text-xs text-slate-500">
            {[['inject_obstacle', 'Inject obstacle on path'], ['dynamic_obstacle', 'Walking person'], ['degrade_vision', 'Degrade vision']].map(([k, l]) => (
              <label key={k} className="flex items-center gap-1.5"><input type="checkbox" checked={opts[k]} onChange={(e) => setOpts({ ...opts, [k]: e.target.checked })} />{l}</label>
            ))}
          </div>
        </form>
      </Card>

      {task && (<>
        <Card title={`${task.task_id} pipeline`} right={<Badge tone={statusTone(task.status)}>{task.status}</Badge>}><Pipeline task={task} /></Card>
        {task.status === 'needs_confirmation' && (
          <Card className="!border-amber-500/40"><p className="mb-3 text-sm">{task.result?.message}</p><button className="btn-primary" onClick={confirm}>Confirm and execute</button></Card>
        )}
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Parsed result"><pre className="overflow-x-auto rounded-xl bg-slate-100 p-3 font-mono text-xs dark:bg-black/30">{JSON.stringify({ intent: task.intent, destination: task.destination, object: task.target_object, confidence: task.confidence, priority: task.priority }, null, 2)}</pre></Card>
          <Card title="Task plan">
            <ol className="space-y-1.5 text-sm">
              {task.steps.map((s) => <li key={s.step} className="flex items-center justify-between rounded-lg bg-slate-100 px-3 py-1.5 dark:bg-white/5"><span><b>{s.step}.</b> {s.action} <span className="text-slate-500">{s.target}</span></span><Badge tone={statusTone(s.status)}>{s.status}</Badge></li>)}
              {!task.steps.length && <li className="text-slate-500">No plan (command was not executed).</li>}
            </ol>
          </Card>
        </div>
        {task.result && (
          <Card title="Result" right={<Badge tone={statusTone(task.result.status)}>{task.result.status}</Badge>}>
            <p className="text-sm">{task.result.message || task.result.reason}</p>
            {task.result.reason && task.result.status !== 'SUCCESS' && <p className="mt-1 text-sm text-rose-500">Reason: {task.result.reason}</p>}
            <p className="mt-2 text-xs text-slate-500">Confidence: {(task.result.confidence * 100).toFixed(1)}% {task.execution_time_ms ? `| executed in ${task.execution_time_ms} ms wall time` : ''}</p>
            {task.result.checks?.map((c) => <div key={c.check} className="mt-1 text-sm">{c.passed ? '✔' : '✘'} {c.check}</div>)}
          </Card>
        )}
        <Card title="Event timeline">
          <ul className="max-h-64 space-y-1 overflow-y-auto font-mono text-xs">
            {myEvents.map((e) => <li key={e.id}><span className="text-slate-500">{e.time}</span> <b>{e.type}</b> {e.message}</li>)}
          </ul>
        </Card>
      </>)}
    </Page>
  )
}
