import { useCallback, useEffect, useRef, useState } from 'react'
import { Camera, ScanSearch, BrainCircuit, Upload, Square, Play, Send } from 'lucide-react'
import { Badge, Card, Page, Table, pct } from '../components/ui.jsx'
import CameraView from '../components/CameraView.jsx'
import { api } from '../services/api.js'
import { useRobot } from '../hooks/useRobot.jsx'

const DEFAULT_CLASSES = 'person, water bottle, tea cup, pen, pencil, paper sheet, book, notebook, computer mouse, laptop, keyboard, mobile phone, chair, table, keys, backpack'

export default function Vision() {
  const { state, notify } = useRobot()
  const [frame, setFrame] = useState(null)
  const [imagePreview, setImagePreview] = useState(null)
  const [cameraOn, setCameraOn] = useState(false)
  const [modelType, setModelType] = useState('world')
  const [classes, setClasses] = useState(DEFAULT_CLASSES)
  const [threshold, setThreshold] = useState('0.25')
  const [busy, setBusy] = useState(false)
  const [target, setTarget] = useState('')
  const [interpretation, setInterpretation] = useState(null)
  const [command, setCommand] = useState('')
  const [commandResult, setCommandResult] = useState(null)
  const videoRef = useRef(null)
  const previewRef = useRef(null)
  const captureRef = useRef(null)
  const streamRef = useRef(null)

  useEffect(() => { if (state?.detections && !cameraOn) setFrame(state.detections) }, [state?.detections, cameraOn])

  useEffect(() => {
    let raf
    const draw = () => {
      const video = videoRef.current
      const canvas = previewRef.current
      if (video && canvas && video.videoWidth && video.videoHeight) {
        if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
          canvas.width = video.videoWidth
          canvas.height = video.videoHeight
        }
        const ctx = canvas.getContext('2d')
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
        const result = frame?.mode === 'real_camera' ? frame : null
        for (const d of (result?.detections || [])) {
          const b = d.bbox || {}
          ctx.lineWidth = Math.max(2, canvas.width / 400)
          ctx.strokeStyle = '#22d3ee'
          ctx.strokeRect(b.x, b.y, b.w, b.h)
          const label = `${d.label} ${Math.round((d.confidence || 0) * 100)}%`
          ctx.font = `${Math.max(14, canvas.width / 55)}px sans-serif`
          const w = ctx.measureText(label).width + 12
          ctx.fillStyle = '#22d3ee'
          ctx.fillRect(b.x, Math.max(0, b.y - 26), w, 25)
          ctx.fillStyle = '#07111f'
          ctx.fillText(label, b.x + 6, Math.max(17, b.y - 8))
        }
      }
      raf = requestAnimationFrame(draw)
    }
    raf = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(raf)
  }, [frame])

  const startCamera = async () => {
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera access needs localhost or HTTPS and a supported browser.')
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()
      }
      setCameraOn(true)
      notify('Webcam started. Choose Detect frame to run inference.', 'success')
    } catch (e) {
      notify(e.message || 'Could not access webcam. Check browser camera permissions.', 'error')
    }
  }

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null
    if (videoRef.current) videoRef.current.srcObject = null
    setCameraOn(false)
  }
  useEffect(() => () => streamRef.current?.getTracks().forEach((track) => track.stop()), [])

  const detectBlob = useCallback(async (blob, filename = 'webcam-frame.jpg') => {
    setBusy(true)
    setImagePreview(URL.createObjectURL(blob))
    setInterpretation(null)
    try {
      const form = new FormData()
      form.append('file', blob, filename)
      form.append('model_type', modelType)
      form.append('classes', classes)
      form.append('confidence_threshold', threshold)
      const response = await fetch('/api/vision/detect-image', { method: 'POST', body: form })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) throw new Error(data.detail || data.message || `Detection failed (${response.status})`)
      setFrame(data)
      setInterpretation(data.semantic || null)
      notify(`Detection complete: ${(data.detections || []).length} object(s).`, 'success')
    } catch (e) {
      notify(e.message || 'Vision request failed.', 'error')
    } finally {
      setBusy(false)
    }
  }, [modelType, classes, threshold, notify])

  const scanSimulation = () => api('/vision/detect', { method: 'POST' }).then((result) => { setFrame(result); setImagePreview(null); setInterpretation(null) }).catch((e) => notify(e.message, 'error'))

  const scanFrame = () => {
    const video = videoRef.current
    const canvas = captureRef.current
    if (!video || !video.videoWidth || !canvas) return notify('Start the webcam first.', 'error')
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height)
    canvas.toBlob((blob) => { if (blob) detectBlob(blob) }, 'image/jpeg', 0.88)
  }

  const uploadImage = (event) => {
    const file = event.target.files?.[0]
    if (file) detectBlob(file, file.name)
    event.target.value = ''
  }

  const askAboutScene = async () => {
    if (!frame?.detections) return notify('Detect an image or run a simulation scan first.', 'error')
    try {
      const result = await api('/vision/interpret', { method: 'POST', body: { detections: frame.detections, target: target || null } })
      setInterpretation(result)
    } catch (e) { notify(e.message, 'error') }
  }

  const submitTask = async () => {
    if (!command.trim()) return
    try {
      const result = await api('/commands', { method: 'POST', body: { command, wait: true } })
      setCommandResult(result)
      notify('Command submitted to the existing robot workflow.', 'success')
    } catch (e) { notify(e.message, 'error') }
  }

  const detections = frame?.detections || []
  const realFrame = frame?.mode === 'real_camera'

  return (
    <Page title="Camera / Vision" subtitle="Real webcam inference, optional open-vocabulary detection, semantic interpretation and task hand-off. Simulation remains available.">
      <div className="grid gap-4 xl:grid-cols-3">
        <Card title="Live camera / image inference" icon={Camera} className="xl:col-span-2" right={<div className="flex flex-wrap gap-2"><button className="btn-secondary" onClick={scanSimulation}>Simulation scan</button><button className="btn-primary" onClick={cameraOn ? stopCamera : startCamera}>{cameraOn ? <><Square size={14} className="inline mr-1"/>Stop camera</> : <><Play size={14} className="inline mr-1"/>Start webcam</>}</button><button className="btn-secondary" disabled={!cameraOn || busy} onClick={scanFrame}><ScanSearch size={14} className="inline mr-1"/>{busy ? 'Detecting…' : 'Detect frame'}</button></div>}>
          <video ref={videoRef} className="hidden" muted playsInline />
          <canvas ref={captureRef} className="hidden" />
          {cameraOn ? <canvas ref={previewRef} className="w-full rounded-xl bg-slate-950" /> : imagePreview && realFrame ? <img src={imagePreview} alt="Last image sent to the detector" className="w-full rounded-xl bg-slate-950" /> : <CameraView result={frame || state?.detections} />}
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
            <span>{cameraOn ? 'Webcam active — detections update when you press Detect frame.' : 'Camera stopped. Start webcam or upload a still image.'}</span>
            <label className="btn-secondary cursor-pointer"><Upload size={14} className="inline mr-1"/>Upload image<input className="hidden" type="file" accept="image/jpeg,image/png,image/webp" onChange={uploadImage}/></label>
          </div>
        </Card>
        <Card title="Detection settings" icon={ScanSearch}>
          <label className="mb-1 block text-xs text-slate-500">Detector</label>
          <select className="input w-full" value={modelType} onChange={(e) => setModelType(e.target.value)}><option value="world">YOLO-World — open vocabulary</option><option value="yolo">YOLOv8n — standard COCO classes</option></select>
          <label className="mb-1 mt-3 block text-xs text-slate-500">Confidence threshold</label>
          <select className="input w-full" value={threshold} onChange={(e) => setThreshold(e.target.value)}><option value="0.15">15% — more detections, more false positives</option><option value="0.25">25% — balanced starting point</option><option value="0.4">40% — fewer, stronger detections</option><option value="0.6">60% — conservative</option></select>
          {modelType === 'world' && <><label className="mb-1 mt-3 block text-xs text-slate-500">Object prompts (comma-separated)</label><textarea className="input min-h-28 w-full" value={classes} onChange={(e) => setClasses(e.target.value)} placeholder="pen, pencil, paper sheet, book, tea cup"/><p className="mt-1 text-xs text-slate-500">Try specific labels such as “ballpoint pen”, “pencil”, “paper sheet”, “book”, “tea cup”, and “computer mouse”. Model support varies.</p></>}
          <p className="mt-3 text-xs text-amber-300">First real inference may download model weights. CPU inference can be slow. Objects can be missed, especially small or occluded items.</p>
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-2 mt-4">
        <Card title="Semantic understanding" icon={BrainCircuit}>
          <p className="text-sm">{frame?.scene?.caption || 'Detect objects first, then ask what the scene contains or search for a target.'}</p>
          <div className="mt-3 flex flex-col sm:flex-row gap-2"><input className="input flex-1" value={target} onChange={(e) => setTarget(e.target.value)} placeholder="Target object, e.g. pen or water bottle"/><button className="btn-primary" onClick={askAboutScene}>Understand scene</button></div>
          {frame?.notice && <p className="mt-2 text-xs text-amber-300">{frame.notice}</p>}
          {interpretation && <div className="mt-3 rounded-lg border border-slate-700 p-3"><p className="text-sm font-medium">{interpretation.summary}</p>{interpretation.evidence?.length > 0 && <ul className="mt-2 list-disc pl-5 text-xs text-slate-400">{interpretation.evidence.map((item, i) => <li key={i}>{item}</li>)}</ul>}<h4 className="mt-3 text-xs font-semibold uppercase tracking-wide text-slate-400">Recommended next steps</h4><ol className="mt-1 list-decimal pl-5 text-xs text-slate-400">{interpretation.recommended_next_steps?.map((item, i) => <li key={i}>{item}</li>)}</ol></div>}
        </Card>
        <Card title="Task hand-off" icon={Send}>
          <p className="text-sm text-slate-400">After checking the detections, send a natural-language command through the existing planner, permission checks, navigation and verification workflow.</p>
          <div className="mt-3 flex flex-col gap-2"><input className="input w-full" value={command} onChange={(e) => setCommand(e.target.value)} placeholder="e.g. Go to the kitchen and find a water bottle"/><button className="btn-primary self-start" onClick={submitTask} disabled={!command.trim()}>Submit robot task</button></div>
          {commandResult && <pre className="mt-3 max-h-40 overflow-auto rounded-lg bg-slate-950 p-3 text-xs text-slate-300">{JSON.stringify(commandResult, null, 2)}</pre>}
          <p className="mt-3 text-xs text-amber-300">Safety boundary: a real-camera detection is not a map coordinate. This button submits the command to your existing workflow; it does not automatically navigate to the detected real-world object.</p>
        </Card>
      </div>

      <Card title={`Detections (${detections.length})`}>
        <Table head={['Label', 'Confidence', 'Source', 'Bounding box', 'Timestamp']}>
          {detections.map((d) => <tr key={d.id || `${d.label}-${d.bbox?.x}`}><td className="td font-medium">{d.label}</td><td className="td"><Badge tone={d.confidence >= 0.85 ? 'green' : d.confidence >= 0.6 ? 'amber' : 'red'}>{pct(d.confidence)}</Badge></td><td className="td">{d.source || frame?.model || 'simulation'}</td><td className="td font-mono text-xs">{d.bbox ? `${d.bbox.x},${d.bbox.y} ${d.bbox.w}x${d.bbox.h}` : '-'}</td><td className="td text-xs">{frame?.timestamp || '-'}</td></tr>)}
        </Table>
        {!detections.length && <p className="text-sm text-slate-500">No detections yet. Start the webcam and detect a frame, upload an image, or use Scan now in simulation mode.</p>}
      </Card>
    </Page>
  )
}
