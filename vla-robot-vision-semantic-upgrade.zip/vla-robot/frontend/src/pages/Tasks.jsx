import { useState } from 'react'
import { Badge, Card, Page, Table, statusTone } from '../components/ui.jsx'
import { usePoll } from '../hooks/usePoll.js'

export default function Tasks() {
  const [tasks] = usePoll('/tasks', null, 2000)
  const [open, setOpen] = useState(null)
  return (
    <Page title="Tasks" subtitle="Every command becomes a task with steps, confidence and a verified result.">
      <Card>
        <Table head={['Task', 'Time', 'Command', 'Intent', 'Priority', 'Conf.', 'Status', 'Exec ms']}>
          {(tasks || []).flatMap((t) => [
            <tr key={t.task_id} className="cursor-pointer hover:bg-slate-100/60 dark:hover:bg-white/5" onClick={() => setOpen(open === t.task_id ? null : t.task_id)}>
              <td className="td font-mono">{t.task_id}</td><td className="td text-xs">{t.timestamp.slice(11)}</td><td className="td">{t.command}</td><td className="td text-xs">{t.intent}</td>
              <td className="td"><Badge tone={t.priority === 'critical' ? 'red' : 'slate'}>{t.priority}</Badge></td><td className="td">{(t.confidence * 100).toFixed(0)}%</td>
              <td className="td"><Badge tone={statusTone(t.status)}>{t.status}</Badge></td><td className="td">{t.execution_time_ms ?? '-'}</td>
            </tr>,
            open === t.task_id && (
              <tr key={t.task_id + 'd'}><td colSpan={8} className="bg-slate-100/60 p-3 dark:bg-white/5">
                <div className="mb-2 text-sm">{t.result?.message || t.result?.reason}</div>
                {t.steps.map((s) => <div key={s.step} className="flex items-center gap-2 text-xs"><Badge tone={statusTone(s.status)}>{s.status}</Badge>{s.step}. {s.action} {s.target} <span className="text-slate-500">{s.duration_ms != null ? `${s.duration_ms} ms` : ''}</span></div>)}
              </td></tr>),
          ])}
        </Table>
        {tasks?.length === 0 && <p className="p-4 text-sm text-slate-500">No tasks yet - send a command.</p>}
      </Card>
    </Page>
  )
}
