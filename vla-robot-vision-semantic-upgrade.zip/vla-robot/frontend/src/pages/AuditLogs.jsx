import { useState } from 'react'
import { Badge, Card, Page, Table } from '../components/ui.jsx'
import { usePoll } from '../hooks/usePoll.js'

const TYPES = ['', 'COMMAND_RECEIVED', 'INTENT_RECOGNIZED', 'TASK_CREATED', 'TASK_PLANNED', 'PATH_PLANNED', 'NAVIGATION_STARTED', 'OBSTACLE_DETECTED', 'PATH_REPLANNED',
  'DESTINATION_REACHED', 'OBJECT_DETECTED', 'TOOL_CALL', 'TASK_VERIFIED', 'TASK_COMPLETED', 'TASK_FAILED', 'SAFETY_EVENT', 'ACCESS_DENIED']

export default function AuditLogs() {
  const [type, setType] = useState('')
  const [search, setSearch] = useState('')
  const [severity, setSeverity] = useState('')
  const [logs] = usePoll('/audit/logs', { type, search, severity, limit: 300 }, 1500)
  const [db] = usePoll('/audit/db-counts', null, 5000)
  return (
    <Page title="Audit Logs" subtitle="Every important event is timestamped and persisted to SQLite.">
      <Card>
        <div className="mb-3 grid gap-2 md:grid-cols-4">
          <input className="input" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} />
          <select className="input" value={type} onChange={(e) => setType(e.target.value)}>{TYPES.map((t) => <option key={t} value={t}>{t || 'All event types'}</option>)}</select>
          <select className="input" value={severity} onChange={(e) => setSeverity(e.target.value)}><option value="">All severities</option><option>info</option><option>warning</option><option>error</option></select>
          <div className="self-center text-xs text-slate-500">DB rows: {db?.audit_logs ?? (db?.error ? 'unavailable' : '-')}</div>
        </div>
        <Table head={['Time', 'Event', 'Message', 'Task', 'Severity']}>
          {(logs || []).map((e) => (
            <tr key={e.id}><td className="td font-mono text-xs">{e.time}</td><td className="td font-mono text-xs font-semibold">{e.type}</td><td className="td">{e.message}</td><td className="td font-mono text-xs">{e.task_id}</td>
              <td className="td"><Badge tone={e.severity === 'info' ? 'slate' : e.severity === 'warning' ? 'amber' : 'red'}>{e.severity}</Badge></td></tr>
          ))}
        </Table>
      </Card>
    </Page>
  )
}
