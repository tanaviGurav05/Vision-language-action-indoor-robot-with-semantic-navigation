import { Activity, Bot, Brain, Gauge, Navigation as Nav } from 'lucide-react'
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Badge, Card, Page, Stat } from '../components/ui.jsx'
import RobotMap from '../components/RobotMap.jsx'
import { usePoll } from '../hooks/usePoll.js'
import { useRobot } from '../hooks/useRobot.jsx'

export default function Overview() {
  const { state, connected } = useRobot()
  const [m] = usePoll('/metrics')
  const [sys] = usePoll('/system/status', null, 5000)
  const r = state?.robot, nav = state?.navigation || {}
  const hist = (m?.history || []).map((h, i) => ({ n: i + 1, time: h.duration_s, conf: +(h.confidence * 100).toFixed(1), eff: h.path_length ? +(Math.min(1, h.optimal_length / h.path_length) * 100).toFixed(1) : 0 }))
  const tip = { contentStyle: { background: '#0f172a', border: 'none', borderRadius: 12, color: '#e2e8f0' } }

  return (
    <Page title="Overview" subtitle="Live status of the robot, AI stack and navigation - streamed over WebSocket.">
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Card title="Robot" icon={Bot} right={<Badge tone={connected && sys?.robot_connected ? 'green' : 'red'}>{connected ? 'Online' : 'Offline'}</Badge>}>
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Mode" value={state?.mode} />
            <Stat label="Battery" value={r ? `${r.battery.toFixed(1)}%` : '-'} />
            <Stat label="Position" value={r ? `${r.x}, ${r.y}` : '-'} sub={r ? `${r.orientation}° | ${r.status}` : ''} />
            <Stat label="Task" value={state?.task?.task_id || 'idle'} sub={state?.task?.command} />
          </div>
        </Card>
        <Card title="AI stack" icon={Brain}>
          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Vision</span><span>{sys?.ai.vision_model}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Language</span><span>{sys?.ai.language_model}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Planner</span><span>{sys?.ai.planner}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Min. confidence</span><span>{sys ? `${sys.ai.confidence_threshold * 100}%` : '-'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Last task conf.</span><span>{m?.history?.length ? `${(m.history.at(-1).confidence * 100).toFixed(0)}%` : '-'}</span></div>
          </div>
        </Card>
        <Card title="Navigation" icon={Nav}>
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Status" value={nav.status || 'idle'} />
            <Stat label="Target" value={nav.destination || '-'} />
            <Stat label="Distance" value={nav.distance ? `${nav.distance} m` : '-'} />
            <Stat label="Path pts" value={state?.planned_path?.length || 0} sub={`actual ${state?.actual_path?.length || 0}`} />
          </div>
        </Card>
        <Card title="Performance" icon={Gauge}>
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Success" value={m ? `${m.task_success_rate}%` : '-'} sub={`${m?.tasks_total ?? 0} tasks`} />
            <Stat label="Avg time" value={m ? `${m.avg_completion_time_s}s` : '-'} />
            <Stat label="Collisions" value={m?.collision_count ?? '-'} tone={m?.collision_count ? 'text-rose-500' : 'text-emerald-500'} />
            <Stat label="Latency" value={m ? `${m.planning_latency_ms} ms` : '-'} />
          </div>
        </Card>
      </div>
      <div className="grid gap-4 xl:grid-cols-3">
        <Card title="Live map" icon={Activity} className="xl:col-span-2"><RobotMap height={420} /></Card>
        <div className="space-y-4">
          <Card title="Completion time per task (s)">
            <ResponsiveContainer width="100%" height={150}><LineChart data={hist}><CartesianGrid strokeDasharray="3 3" opacity={0.15} /><XAxis dataKey="n" fontSize={11} /><YAxis fontSize={11} /><Tooltip {...tip} /><Line type="monotone" dataKey="time" stroke="#6366f1" strokeWidth={2} dot={false} /></LineChart></ResponsiveContainer>
          </Card>
          <Card title="Confidence & path efficiency (%)">
            <ResponsiveContainer width="100%" height={150}><BarChart data={hist}><CartesianGrid strokeDasharray="3 3" opacity={0.15} /><XAxis dataKey="n" fontSize={11} /><YAxis fontSize={11} domain={[0, 100]} /><Tooltip {...tip} /><Bar dataKey="conf" fill="#22d3ee" radius={4} /><Bar dataKey="eff" fill="#a78bfa" radius={4} /></BarChart></ResponsiveContainer>
          </Card>
        </div>
      </div>
    </Page>
  )
}
