import { useState } from 'react'
import { Badge, Card, Page, Table, statusTone } from '../components/ui.jsx'
import { usePoll } from '../hooks/usePoll.js'
import { api } from '../services/api.js'
import { useRobot } from '../hooks/useRobot.jsx'

const TONE = { READ: 'green', CONTROL: 'amber', HIGH_RISK: 'red', SAFETY_STOP: 'blue' }

export default function Tools() {
  const { role, notify } = useRobot()
  const [tools] = usePoll('/tools', null, 60000)
  const [hist, reload] = usePoll('/tools/history', null, 2500)
  const [tool, setTool] = useState('get_robot_status')
  const [args, setArgs] = useState('{}')
  const [asRole, setAsRole] = useState(role)
  const [confirm, setConfirm] = useState(false)
  const [out, setOut] = useState(null)

  const run = async () => {
    let parsed
    try { parsed = JSON.parse(args || '{}') } catch { return notify('Arguments must be valid JSON', 'error') }
    try { setOut(await api('/tools/execute', { method: 'POST', body: { tool, arguments: parsed, role: asRole, confirm } })); reload() } catch (e) { notify(e.message, 'error') }
  }
  return (
    <Page title="Tools" subtitle="Function-calling layer with schemas, permission levels, timing and audit.">
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {(tools || []).map((t) => (
          <Card key={t.name}>
            <div className="flex items-center justify-between"><b className="font-mono text-sm">{t.name}</b><Badge tone={TONE[t.permission]}>{t.permission}</Badge></div>
            <p className="mt-1 text-sm text-slate-500">{t.description}</p>
            <pre className="mt-2 overflow-x-auto rounded-lg bg-slate-100 p-2 font-mono text-[11px] dark:bg-black/30">{JSON.stringify(t.input_schema.properties)}</pre>
          </Card>
        ))}
      </div>
      <Card title="Execute a tool">
        <div className="grid gap-3 md:grid-cols-4">
          <select className="input" value={tool} onChange={(e) => setTool(e.target.value)}>{(tools || []).map((t) => <option key={t.name}>{t.name}</option>)}</select>
          <input className="input font-mono" value={args} onChange={(e) => setArgs(e.target.value)} placeholder='{"location":"Kitchen"}' />
          <select className="input" value={asRole} onChange={(e) => setAsRole(e.target.value)}><option>viewer</option><option>operator</option><option>admin</option></select>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} />confirmed</label>
        </div>
        <button className="btn-primary mt-3" onClick={run}>Execute</button>
        {out && <pre className="mt-3 max-h-64 overflow-auto rounded-xl bg-slate-100 p-3 font-mono text-xs dark:bg-black/30">{JSON.stringify(out, null, 2)}</pre>}
      </Card>
      <Card title="Call history">
        <Table head={['Call', 'Tool', 'Role', 'Permission', 'Status', 'Time', 'Error']}>
          {(hist || []).slice(0, 30).map((c) => <tr key={c.call_id}><td className="td font-mono text-xs">{c.call_id}</td><td className="td">{c.tool}</td><td className="td">{c.role}</td><td className="td text-xs">{c.permission}</td><td className="td"><Badge tone={statusTone(c.status)}>{c.status}</Badge></td><td className="td">{c.execution_ms} ms</td><td className="td text-xs text-slate-500">{c.error}</td></tr>)}
        </Table>
      </Card>
    </Page>
  )
}
