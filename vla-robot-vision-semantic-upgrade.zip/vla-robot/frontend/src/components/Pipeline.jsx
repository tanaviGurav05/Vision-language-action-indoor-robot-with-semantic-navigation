import { Check, Loader2, X, Circle } from 'lucide-react'

// Derive pipeline stage status from a task (works for live updates, since the task is re-sent on each step).
export function stagesFor(task) {
  if (!task) return []
  const step = (a) => task.steps.find((s) => s.action === a)
  const st = (s) => (!s ? 'pending' : s.status === 'done' ? 'done' : s.status === 'failed' ? 'failed' : s.status === 'running' ? 'running' : 'pending')
  const finished = ['completed', 'failed', 'denied', 'rejected', 'needs_confirmation'].includes(task.status)
  const blocked = ['denied', 'rejected', 'needs_confirmation'].includes(task.status)
  const hasPlan = task.steps.length > 0
  const vision = [step('scan'), step('detect_object')].filter(Boolean)
  return [
    { name: 'Command', detail: 'received', s: 'done' },
    { name: 'Parser', detail: task.parsed ? `intent ${task.parsed.intent}` : '', s: 'done' },
    { name: 'Entities', detail: [task.destination, task.target_object].filter(Boolean).join(' / ') || '-', s: blocked && !hasPlan ? (task.status === 'denied' ? 'failed' : 'failed') : 'done' },
    { name: 'Planner', detail: hasPlan ? `${task.steps.length} steps` : '-', s: hasPlan ? 'done' : blocked ? 'failed' : 'pending' },
    { name: 'Navigation', detail: step('navigate')?.target || '-', s: st(step('navigate')) },
    { name: 'Vision', detail: vision.length ? 'scan + detect' : '-', s: vision.length ? (vision.some((v) => v.status === 'failed') ? 'failed' : vision.every((v) => v.status === 'done') ? 'done' : vision.some((v) => v.status === 'running') ? 'running' : 'pending') : 'pending' },
    { name: 'Verification', detail: task.result?.status || '-', s: st(step('verify')) },
    { name: 'Response', detail: finished ? task.status : '-', s: finished ? (task.status === 'completed' ? 'done' : 'failed') : 'pending' },
  ]
}

const ICON = { done: <Check size={14} />, failed: <X size={14} />, running: <Loader2 size={14} className="animate-spin" />, pending: <Circle size={10} /> }
const TONE = { done: 'bg-emerald-500 text-white', failed: 'bg-rose-500 text-white', running: 'bg-sky-500 text-white', pending: 'bg-slate-300 text-slate-500 dark:bg-white/10' }

export default function Pipeline({ task }) {
  const stages = stagesFor(task)
  if (!stages.length) return <p className="text-sm text-slate-500">Submit a command to see the pipeline.</p>
  return (
    <ol className="flex flex-wrap items-start gap-y-3">
      {stages.map((g, i) => (
        <li key={g.name} className="flex items-start">
          <div className="flex w-28 flex-col items-center text-center">
            <span className={`grid h-8 w-8 place-items-center rounded-full ${TONE[g.s]} transition-colors`}>{ICON[g.s]}</span>
            <span className="mt-1 text-xs font-semibold">{g.name}</span>
            <span className="max-w-[7rem] truncate text-[11px] text-slate-500">{g.detail}</span>
          </div>
          {i < stages.length - 1 && <div className={`mt-4 h-0.5 w-4 ${g.s === 'done' ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-white/10'}`} />}
        </li>
      ))}
    </ol>
  )
}
