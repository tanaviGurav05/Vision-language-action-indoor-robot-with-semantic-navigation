// Synthetic camera frame: the sim has no pixels, so we render detections as a HUD over a perspective grid.
const COLORS = ['#22d3ee', '#a78bfa', '#34d399', '#fbbf24', '#f472b6']

export default function CameraView({ result }) {
  const dets = result?.detections || []
  return (
    <div className="overflow-hidden rounded-xl bg-slate-900">
      <svg viewBox="0 0 640 480" className="w-full">
        <defs><linearGradient id="fl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#1e293b" /><stop offset="1" stopColor="#0f172a" /></linearGradient></defs>
        <rect width="640" height="480" fill="url(#fl)" />
        {[...Array(12)].map((_, i) => <line key={i} x1={i * 58} y1="480" x2={320 + (i - 5.5) * 12} y2="240" stroke="#334155" strokeWidth="1" />)}
        {[0, 1, 2, 3, 4].map((i) => <line key={i} x1="0" x2="640" y1={250 + i * i * 14 + i * 8} y2={250 + i * i * 14 + i * 8} stroke="#334155" strokeWidth="1" />)}
        <rect x="0" y="0" width="640" height="240" fill="#0b1220" opacity=".6" />
        {dets.map((d, i) => {
          const c = COLORS[i % COLORS.length]
          return (
            <g key={d.id}>
              <rect x={d.bbox.x} y={d.bbox.y} width={d.bbox.w} height={d.bbox.h} fill={c} fillOpacity=".12" stroke={c} strokeWidth="2" rx="4" />
              <rect x={d.bbox.x} y={d.bbox.y - 18} width={Math.max(70, d.label.length * 8 + 46)} height="18" fill={c} rx="3" />
              <text x={d.bbox.x + 5} y={d.bbox.y - 5} fontSize="12" fontWeight="600" fill="#0f172a">{d.label} {(d.confidence * 100).toFixed(0)}%</text>
            </g>
          )
        })}
        <circle cx="20" cy="22" r="5" fill="#ef4444"><animate attributeName="opacity" values="1;.2;1" dur="1.2s" repeatCount="indefinite" /></circle>
        <text x="32" y="27" fontSize="13" fill="#e2e8f0" fontFamily="monospace">LIVE  {result?.timestamp || '--'}</text>
        <text x="620" y="466" fontSize="12" fill="#94a3b8" textAnchor="end" fontFamily="monospace">{result?.model || 'no frame yet'}</text>
      </svg>
    </div>
  )
}
