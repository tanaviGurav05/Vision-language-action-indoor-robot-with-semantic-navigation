import { motion } from 'framer-motion'

export function Card({ title, icon: Icon, right, children, className = '' }) {
  return (
    <motion.section initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }} className={`card p-4 ${className}`}>
      {(title || right) && (
        <header className="mb-3 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-600 dark:text-slate-300">
            {Icon && <Icon size={16} className="text-indigo-500" />}{title}
          </h3>
          {right}
        </header>
      )}
      {children}
    </motion.section>
  )
}

const TONES = {
  green: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400',
  red: 'bg-rose-500/15 text-rose-600 dark:text-rose-400',
  amber: 'bg-amber-500/15 text-amber-600 dark:text-amber-400',
  blue: 'bg-sky-500/15 text-sky-600 dark:text-sky-400',
  slate: 'bg-slate-500/15 text-slate-500 dark:text-slate-400',
  indigo: 'bg-indigo-500/15 text-indigo-600 dark:text-indigo-300',
}
export function Badge({ tone = 'slate', children }) {
  return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${TONES[tone]}`}>{children}</span>
}
export const statusTone = (s) =>
  ({ completed: 'green', success: 'green', done: 'green', SUCCESS: 'green', failed: 'red', FAILED: 'red', denied: 'red', DENIED: 'red',
     rejected: 'amber', running: 'blue', planned: 'indigo', needs_confirmation: 'amber', skipped: 'slate', pending: 'slate' }[s] || 'slate')

export function Stat({ label, value, sub, tone }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-wide text-slate-500">{label}</div>
      <div className={`mt-0.5 text-2xl font-semibold ${tone || ''}`}>{value ?? '-'}</div>
      {sub && <div className="text-xs text-slate-500">{sub}</div>}
    </div>
  )
}

export function Table({ head, children }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead><tr className="border-b border-slate-200 dark:border-white/10">{head.map((h) => <th key={h} className="th">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-slate-100 dark:divide-white/5">{children}</tbody>
      </table>
    </div>
  )
}

export const pct = (v) => (v == null ? '-' : `${(v * 100).toFixed(1)}%`)
export const Page = ({ title, subtitle, children }) => (
  <div className="space-y-4">
    <div><h1 className="text-xl font-semibold">{title}</h1>{subtitle && <p className="text-sm text-slate-500">{subtitle}</p>}</div>
    {children}
  </div>
)
