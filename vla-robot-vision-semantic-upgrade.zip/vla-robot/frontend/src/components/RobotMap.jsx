import { useRef, useState } from 'react'
import { useRobot } from '../hooks/useRobot.jsx'

const S = 30 // px per metre
const ICON = { chair: 'C', table: 'T', person: 'P', laptop: 'L', bottle: 'B', 'fire extinguisher': 'F', plant: 'p', sofa: 'S', desk: 'D', door: 'd' }

export default function RobotMap({ selected, onSelect, height = 520 }) {
  const { map, state } = useRobot()
  const [view, setView] = useState({ x: 0, y: 0, k: 1 })
  const drag = useRef(null)
  if (!map) return <div className="p-8 text-sm text-slate-500">Loading map...</div>

  const W = map.width * S, H = map.height * S
  const robot = state?.robot
  const onWheel = (e) => setView((v) => ({ ...v, k: Math.min(3, Math.max(0.5, v.k * (e.deltaY < 0 ? 1.1 : 0.9))) }))
  const down = (e) => { drag.current = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y } }
  const move = (e) => { if (drag.current) setView((v) => ({ ...v, x: drag.current.vx + (e.clientX - drag.current.x), y: drag.current.vy + (e.clientY - drag.current.y) })) }
  const up = () => { drag.current = null }
  const pts = (path) => (path || []).map(([x, y]) => `${x * S + S / 2},${y * S + S / 2}`).join(' ')

  return (
    <div className="relative overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-900/60" style={{ height }}>
      <svg className="h-full w-full cursor-grab select-none active:cursor-grabbing" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet"
           onWheel={onWheel} onMouseDown={down} onMouseMove={move} onMouseUp={up} onMouseLeave={up}>
        <g transform={`translate(${view.x} ${view.y}) scale(${view.k})`} style={{ transformOrigin: `${W / 2}px ${H / 2}px` }}>
          {map.rooms.map((r) => (
            <g key={r.name}>
              <rect x={r.x0 * S} y={r.y0 * S} width={(r.x1 - r.x0 + 1) * S} height={(r.y1 - r.y0 + 1) * S} rx="6"
                    className="fill-indigo-500/10 stroke-indigo-400/30" />
              <text x={r.x0 * S + 8} y={r.y0 * S + 18} className="fill-slate-500 text-[12px] font-semibold uppercase tracking-wider">{r.name}</text>
            </g>
          ))}
          {map.walls.map(([x, y]) => <rect key={`w${x}-${y}`} x={x * S} y={y * S} width={S} height={S} className="fill-slate-600 dark:fill-slate-500" />)}
          {map.doors.map(([x, y]) => <rect key={`d${x}-${y}`} x={x * S + 4} y={y * S + 4} width={S - 8} height={S - 8} rx="3" className="fill-amber-400/60" />)}
          {map.boxes.map(([x, y]) => <rect key={`b${x}-${y}`} x={x * S + 3} y={y * S + 3} width={S - 6} height={S - 6} rx="4" className="fill-orange-500/70" />)}

          {map.objects.map((o) => (
            <g key={o.id}><circle cx={o.x * S + S / 2} cy={o.y * S + S / 2} r="9" className="fill-cyan-500/25 stroke-cyan-400" />
              <text x={o.x * S + S / 2} y={o.y * S + S / 2 + 4} textAnchor="middle" className="fill-cyan-600 dark:fill-cyan-300 text-[10px] font-bold"><title>{o.label}</title>{ICON[o.label] || '?'}</text></g>
          ))}

          {state?.planned_path?.length > 1 && <polyline points={pts(state.planned_path)} fill="none" strokeWidth="3" strokeDasharray="7 6" className="stroke-indigo-400" />}
          {state?.actual_path?.length > 1 && <polyline points={pts(state.actual_path)} fill="none" strokeWidth="3" className="stroke-emerald-400" />}

          {map.landmarks.map((l) => (
            <g key={l.id} className="cursor-pointer" onMouseDown={(e) => e.stopPropagation()} onClick={() => onSelect?.(l)}>
              <circle cx={l.x * S + S / 2} cy={l.y * S + S / 2} r="11" className={selected?.id === l.id ? 'fill-rose-500 stroke-white' : 'fill-violet-500 stroke-white'} strokeWidth="2" />
              <text x={l.x * S + S / 2} y={l.y * S + S / 2 - 16} textAnchor="middle" className="fill-slate-800 dark:fill-white text-[11px] font-semibold">{l.name}</text>
            </g>
          ))}
          {selected && <circle cx={selected.x * S + S / 2} cy={selected.y * S + S / 2} r="8" className="pulse-ring fill-none stroke-rose-500" strokeWidth="2" />}

          {(state?.dynamic_obstacles || []).map((o) => (
            <g key={o.id} style={{ transform: `translate(${o.x * S + S / 2}px, ${o.y * S + S / 2}px)`, transition: 'transform .15s linear' }}>
              <circle r="11" className="fill-rose-500/80 stroke-white" strokeWidth="2" />
              <text y="4" textAnchor="middle" className="fill-white text-[11px] font-bold">{o.kind === 'person' ? 'P' : '!'}</text>
            </g>
          ))}

          {robot && (
            <g style={{ transform: `translate(${robot.x * S + S / 2}px, ${robot.y * S + S / 2}px)`, transition: 'transform .15s linear' }}>
              <circle r="16" className={robot.estopped ? 'fill-rose-500/30' : 'fill-emerald-400/25'} />
              <g style={{ transform: `rotate(${robot.orientation}deg)`, transition: 'transform .15s' }}>
                <circle r="11" className={robot.estopped ? 'fill-rose-600' : 'fill-emerald-500'} stroke="white" strokeWidth="2" />
                <polygon points="14,0 6,-5 6,5" fill="white" />
              </g>
            </g>
          )}
        </g>
      </svg>
      <div className="absolute bottom-2 left-2 flex gap-1.5 text-xs">
        <button className="btn-ghost !px-2 !py-1" onClick={() => setView((v) => ({ ...v, k: Math.min(3, v.k * 1.2) }))}>+</button>
        <button className="btn-ghost !px-2 !py-1" onClick={() => setView((v) => ({ ...v, k: Math.max(0.5, v.k / 1.2) }))}>-</button>
        <button className="btn-ghost !px-2 !py-1" onClick={() => setView({ x: 0, y: 0, k: 1 })}>Reset</button>
      </div>
      <div className="absolute right-2 top-2 space-y-0.5 rounded-lg bg-black/40 p-2 text-[11px] text-white">
        <div><span className="mr-1 inline-block h-2 w-2 rounded-full bg-violet-500" />Landmark</div>
        <div><span className="mr-1 inline-block h-2 w-2 rounded-full bg-cyan-400" />Object</div>
        <div><span className="mr-1 inline-block h-2 w-2 rounded-full bg-orange-500" />Static box</div>
        <div><span className="mr-1 inline-block h-2 w-2 rounded-full bg-rose-500" />Dynamic obstacle</div>
        <div><span className="mr-1 inline-block h-0.5 w-3 bg-indigo-400" />Planned path</div>
        <div><span className="mr-1 inline-block h-0.5 w-3 bg-emerald-400" />Actual path</div>
      </div>
    </div>
  )
}
