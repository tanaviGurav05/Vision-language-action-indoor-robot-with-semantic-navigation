import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import { RobotProvider } from './hooks/useRobot.jsx'
import './index.css'

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <RobotProvider>
      <App />
    </RobotProvider>
  </BrowserRouter>
)
