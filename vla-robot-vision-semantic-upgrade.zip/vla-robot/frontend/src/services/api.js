// Thin fetch wrapper: surfaces the backend's friendly error messages.
export async function api(path, { method = 'GET', body, params } = {}) {
  const qs = params ? '?' + new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null)) : ''
  let res
  try {
    res = await fetch(`/api${path}${qs}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    })
  } catch {
    throw new Error('Cannot reach the backend. Is it running on port 8000?')
  }
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.message || (Array.isArray(data.detail) ? 'Invalid input.' : data.detail) || `Request failed (${res.status})`)
  return data
}
