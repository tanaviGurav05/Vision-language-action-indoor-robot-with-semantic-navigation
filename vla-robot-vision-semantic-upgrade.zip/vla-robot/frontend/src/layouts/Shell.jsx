import { NavLink, Outlet } from 'react-router-dom'
import { Activity, AlertTriangle, BarChart3, Bot, Camera, Gamepad2, ListChecks, Map as MapIcon, Moon, Navigation, ScrollText,
  Settings as SettingsIcon, ShieldAlert, Sun, Terminal, Wrench, BatteryMedium } from 'lucide-react'
import { useRobot } from '../hooks/useRobot.jsx'
import { api } from '../services/api.js'
import { Badge } from '../components/ui.jsx'

const NAV = [
  ['/', 'Overview', Activity], ['/control', 'Robot Control', Gamepad2], ['/command', 'Command', Terminal], ['/map', 'Semantic Map', MapIcon],
  ['/vision', 'Camera / Vision', Camera], ['/navigation', 'Navigation', Navigation], ['/tasks', 'Tasks', ListChecks], ['/tools', 'Tools', Wrench],
  ['/safety', 'Safety', ShieldAlert], ['/audit', 'Audit Logs', ScrollText], ['/metrics', 'Metrics & Experiments', BarChart3], ['/settings', 'Settings', SettingsIcon],
]

export default function Shell() {
  const { state, connected, theme, setTheme, notify, toast } = useRobot()
  const robot = state?.robot
  const estop = async () => {
    try { await api('/safety/emergency-stop', { method: 'POST' }); notify('EMERGENCY STOP engaged', 'error') } catch (e) { notify(e.message, 'error') }
  }
  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r border-slate-200 bg-white/60 p-3 backdrop-blur dark:border-white/10 dark:bg-black/20 md:flex">
        <div className="mb-4 flex items-center gap-2 px-2 pt-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-400 text-white"><Bot size={20} /></span>
          <div><div className="text-sm font-bold leading-tight">VLA Robot</div><div className="text-[11px] text-slate-500">Control Center</div></div>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto">
          {NAV.map(([to, label, Icon]) => (
            <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) =>
              `flex items-center gap-2.5 rounded-xl px-3 py-2 text-sm transition ${isActive ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'text-slate-600 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-white/10'}`}>
              <Icon size={16} />{label}
            </NavLink>
          ))}
        </nav>
        <div className="mt-2 rounded-xl bg-slate-200/60 p-3 text-xs dark:bg-white/5">
          <div className="flex items-center justify-between"><span>Backend</span><Badge tone={connected ? 'green' : 'red'}>{connected ? 'online' : 'offline'}</Badge></div>
          <div className="mt-1 flex items-center justify-between"><span>Mode</span><Badge tone="indigo">{state?.mode || '-'}</Badge></div>
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-slate-200 bg-white/70 px-4 py-2.5 backdrop-blur dark:border-white/10 dark:bg-slate-950/60">
          <nav className="flex gap-1 overflow-x-auto md:hidden">
            {NAV.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `whitespace-nowrap rounded-lg px-2 py-1 text-xs ${isActive ? 'bg-indigo-600 text-white' : ''}`}>{label}</NavLink>)}
          </nav>
          <div className="ml-auto hidden items-center gap-4 text-sm sm:flex">
            <span className="flex items-center gap-1.5 text-slate-500"><BatteryMedium size={16} />{robot ? `${robot.battery.toFixed(1)}%` : '-'}</span>
            <span className="font-mono text-xs text-slate-500">{robot ? `(${robot.x}, ${robot.y})` : '-'}</span>
            {state?.estop && <Badge tone="red">E-STOP ACTIVE</Badge>}
          </div>
          <button className="btn-ghost !p-2" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="Toggle theme">{theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}</button>
          <button onClick={estop} className="btn bg-rose-600 font-bold tracking-wide text-white shadow-lg shadow-rose-600/40 hover:bg-rose-500">
            <AlertTriangle size={16} /> E-STOP
          </button>
        </header>
        <main className="p-4 md:p-6"><Outlet /></main>
      </div>

      {toast && (
        <div key={toast.id} className={`fixed bottom-4 right-4 z-50 max-w-sm rounded-xl px-4 py-3 text-sm text-white shadow-2xl ${toast.kind === 'error' ? 'bg-rose-600' : 'bg-slate-800'}`}>{toast.message}</div>
      )}
    </div>
  )
}
