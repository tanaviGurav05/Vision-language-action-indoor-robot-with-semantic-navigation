import { useCallback, useEffect, useState } from 'react'
import { api } from '../services/api.js'

// Poll a REST endpoint; returns [data, reload].
export function usePoll(path, params, ms = 3000) {
  const [data, setData] = useState(null)
  const key = JSON.stringify(params || {})
  const load = useCallback(() => api(path, { params }).then(setData).catch(() => {}), [path, key]) // eslint-disable-line
  useEffect(() => {
    load()
    const t = setInterval(load, ms)
    return () => clearInterval(t)
  }, [load, ms])
  return [data, load]
}
