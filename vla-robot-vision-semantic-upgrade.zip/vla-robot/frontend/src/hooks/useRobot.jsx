import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { api } from '../services/api.js'

const Ctx = createContext(null)
export const useRobot = () => useContext(Ctx)

export function RobotProvider({ children }) {
  const [state, setState] = useState(null)       // live robot snapshot
  const [connected, setConnected] = useState(false)
  const [events, setEvents] = useState([])       // live audit events (newest first)
  const [task, setTask] = useState(null)         // latest task
  const [map, setMap] = useState(null)
  const [theme, setTheme] = useState(localStorage.getItem('theme') || 'dark')
  const [role, setRole] = useState(localStorage.getItem('role') || 'operator')
  const [toast, setToast] = useState(null)
  const wsRef = useRef(null)

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
    localStorage.setItem('theme', theme)
  }, [theme])
  useEffect(() => localStorage.setItem('role', role), [role])

  const notify = useCallback((message, kind = 'info') => {
    setToast({ message, kind, id: Date.now() })
    setTimeout(() => setToast(null), 4500)
  }, [])

  const loadMap = useCallback(() => api('/map').then(setMap).catch(() => {}), [])

  useEffect(() => {
    let closed = false, retry
    const connect = () => {
      const proto = location.protocol === 'https:' ? 'wss' : 'ws'
      const ws = new WebSocket(`${proto}://${location.host}/ws`)
      wsRef.current = ws
      ws.onopen = () => setConnected(true)
      ws.onclose = () => { setConnected(false); if (!closed) retry = setTimeout(connect, 1500) }
      ws.onmessage = (e) => {
        const m = JSON.parse(e.data)
        if (m.type === 'state') setState(m)
        else if (m.type === 'audit') setEvents((p) => [m.event, ...p].slice(0, 300))
        else if (m.type === 'task') setTask(m.task)
      }
    }
    connect(); loadMap()
    return () => { closed = true; clearTimeout(retry); wsRef.current?.close() }
  }, [loadMap])

  return (
    <Ctx.Provider value={{ state, connected, events, task, setTask, map, loadMap, theme, setTheme, role, setRole, notify, toast }}>
      {children}
    </Ctx.Provider>
  )
}
