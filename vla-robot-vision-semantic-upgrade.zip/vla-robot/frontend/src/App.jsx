import { Route, Routes } from 'react-router-dom'
import Shell from './layouts/Shell.jsx'
import Overview from './pages/Overview.jsx'
import RobotControl from './pages/RobotControl.jsx'
import Command from './pages/Command.jsx'
import SemanticMap from './pages/SemanticMap.jsx'
import Vision from './pages/Vision.jsx'
import NavigationPage from './pages/Navigation.jsx'
import Tasks from './pages/Tasks.jsx'
import Tools from './pages/Tools.jsx'
import Safety from './pages/Safety.jsx'
import AuditLogs from './pages/AuditLogs.jsx'
import Metrics from './pages/Metrics.jsx'
import Settings from './pages/Settings.jsx'

export default function App() {
  return (
    <Routes>
      <Route element={<Shell />}>
        <Route index element={<Overview />} />
        <Route path="control" element={<RobotControl />} />
        <Route path="command" element={<Command />} />
        <Route path="map" element={<SemanticMap />} />
        <Route path="vision" element={<Vision />} />
        <Route path="navigation" element={<NavigationPage />} />
        <Route path="tasks" element={<Tasks />} />
        <Route path="tools" element={<Tools />} />
        <Route path="safety" element={<Safety />} />
        <Route path="audit" element={<AuditLogs />} />
        <Route path="metrics" element={<Metrics />} />
        <Route path="settings" element={<Settings />} />
      </Route>
    </Routes>
  )
}
