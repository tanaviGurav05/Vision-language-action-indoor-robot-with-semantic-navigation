# Vision-Language-Action Indoor Robot with Semantic Navigation and Tool Use

M.Sc. Artificial Intelligence capstone prototype. A natural-language command is parsed, planned, executed through
permission-checked tools on a simulated robot (A* navigation, obstacle replanning, simulated vision), verified,
logged and shown on a live web dashboard. Runs on a normal Windows laptop: no GPU, ROS 2 or API key needed.

## Objectives
Natural-language understanding, vision + semantic landmark recognition, localization, semantic mapping, A*/Dijkstra
planning, obstacle avoidance, tool calling, task verification, confidence-aware behaviour, safety/permissions,
audit trail, measurable evaluation, monitoring dashboard.

## Architecture
```
React dashboard --REST/WebSocket--> FastAPI --> Engine
   Engine: CommandParser -> TaskPlanner -> ToolManager(+PermissionManager, SafetyManager)
           -> Navigation(A*) / Vision(detector) -> TaskVerifier -> AuditLogger / Metrics -> SQLite
   Robot layer: RobotInterface = SimulationRobot (default) | ROS2Robot (stub)
```
Details: `docs/architecture.md`. Academic write-up: `docs/capstone_report.md`.

## Features
Command pipeline view | interactive SVG semantic map (zoom/pan/click) | live camera HUD with bounding boxes |
8+ tools with schemas and permission levels (READ / CONTROL / HIGH_RISK) | confidence gating (<60% asks to confirm) |
dynamic obstacles + replanning | emergency stop for every role | searchable audit log | metrics from real runs |
7 evaluation scenarios | dark/light theme | SQLite persistence (PostgreSQL-ready).

## Technology stack
Python 3.11+, FastAPI, Pydantic, SQLAlchemy, SQLite, WebSocket, pytest | React 18, Vite, Tailwind CSS,
Recharts, Lucide, Framer Motion | Docker. Optional real vision: Ultralytics YOLOv8 + YOLO-World open-vocabulary image detection (`requirements-vision.txt`), semantic interpretation, and reviewed task hand-off.

## Folder structure
```
backend/  api/ core/ ai/ robotics/ tools/ verification/ safety/ database/ monitoring/ data/
frontend/ src/{components,pages,services,hooks,layouts}
simulation/ tests/ docs/ docker/ docker-compose.yml requirements.txt .env.example
```

## Install and run (Windows, VS Code terminal)
Backend (terminal 1):
```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn backend.main:app --reload
```
Frontend (terminal 2) - needs Node.js 18+:
```
cd frontend
npm install
npm run dev
```
Open http://localhost:5173 (API docs at http://localhost:8000/docs).

## Real webcam and open-vocabulary vision

See `docs/real-vision-semantic-workflow.md`. Install optional dependencies with `python -m pip install -r requirements-vision.txt`, open Camera / Vision, start the webcam, and press Detect frame. YOLO-World can try custom prompts such as pen, pencil, paper sheet, book, tea cup, and computer mouse. These classes are not guaranteed; inspect the image and confidence. A camera bounding box is not a robot-map coordinate, so real-camera detections do not automatically drive a physical robot. The original simulation scan remains available.

## Demo
Command page -> "Go to the kitchen and find a water bottle". Tick "Inject obstacle on path" to watch the robot
stop, replan and continue. "Disable all safety systems" is denied. "go to the kichn" asks for confirmation.

## Docker
`docker compose up --build` -> dashboard on http://localhost:8080.

## Testing
`pytest` (35 tests: commands, planning, A*, obstacles, vision mock, tool permissions, safety, verification, API).

## Evaluation
Metrics page -> "Run all scenarios". Results of a 20-seed run are in `docs/capstone_report.md`.

## Future scope
ROS 2/Nav2 + Gazebo bridge, real camera + YOLO/CLIP, LLM planner with the rule planner as fallback, SLAM maps,
multi-robot, real authentication, PostgreSQL + OpenTelemetry export.
